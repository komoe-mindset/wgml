
import JSZip from 'jszip';
import { Quiz } from '../types';

interface ExportManifest {
  infographics: Record<number, string[]>;
  diagrams: Record<number, string[]>;
  html: Record<number, string>;
  resources?: Record<number, { audio?: string; youtube?: string; questions?: string[]; links?: { title: string; url: string }[] }>;
  quizzes?: Record<number, Quiz>;
}

export const exportTeachingPackage = async (
  chapterImages: Record<number, string[]>,
  chapterDiagrams: Record<number, string[]>,
  chapterHtml: Record<number, string>,
  chapterResources: Record<number, { audio?: string; youtube?: string; questions?: string[]; links?: { title: string; url: string }[] }>,
  chapterQuizzes: Record<number, Quiz>
) => {
  const zip = new JSZip();
  
  const manifest: ExportManifest = {
    infographics: {},
    diagrams: {},
    html: {},
    resources: chapterResources,
    quizzes: chapterQuizzes
  };

  // 1. Save Infographics
  for (const [chapterId, images] of Object.entries(chapterImages)) {
    const folder = zip.folder(`chapter_${chapterId}`);
    const imageFilenames: string[] = [];
    
    if (folder) {
      images.forEach((base64Data, index) => {
        const matches = base64Data.match(/^data:image\/([a-zA-Z+]+);base64,(.+)$/);
        if (matches && matches.length === 3) {
          const extension = matches[1] === 'jpeg' ? 'jpg' : matches[1];
          const content = matches[2];
          const filename = `image_${index}.${extension}`;
          folder.file(filename, content, { base64: true });
          imageFilenames.push(filename);
        }
      });
      manifest.infographics[Number(chapterId)] = imageFilenames;
    }
  }

  // 2. Save Custom Diagrams (Images & PDFs)
  const diagFolder = zip.folder("diagrams");
  if (diagFolder) {
    for (const [chapterId, diagrams] of Object.entries(chapterDiagrams)) {
      const diagramFilenames: string[] = [];
      diagrams.forEach((data, index) => {
        if (data.startsWith('data:image')) {
            const matches = data.match(/^data:image\/([a-zA-Z+]+);base64,(.+)$/);
            if (matches && matches.length === 3) {
                const extension = matches[1] === 'jpeg' ? 'jpg' : matches[1];
                const content = matches[2];
                const filename = `chapter_${chapterId}_diag_${index}.${extension}`;
                diagFolder.file(filename, content, { base64: true });
                diagramFilenames.push(filename);
            }
        } else if (data.startsWith('data:application/pdf')) {
            const matches = data.match(/^data:application\/pdf;base64,(.+)$/);
            if (matches && matches.length === 2) {
                const content = matches[1];
                const filename = `chapter_${chapterId}_diag_${index}.pdf`;
                diagFolder.file(filename, content, { base64: true });
                diagramFilenames.push(filename);
            }
        }
      });
      manifest.diagrams[Number(chapterId)] = diagramFilenames;
    }
  }

  // 3. Save Custom HTML or PDF Content
  const contentFolder = zip.folder("content");
  if (contentFolder) {
    for (const [chapterId, contentData] of Object.entries(chapterHtml)) {
      // Check if content is PDF (base64) or HTML string
      if (contentData.startsWith('data:application/pdf')) {
        // It's a PDF
        const matches = contentData.match(/^data:application\/pdf;base64,(.+)$/);
        if (matches && matches[1]) {
          const filename = `chapter_${chapterId}.pdf`;
          contentFolder.file(filename, matches[1], { base64: true });
          manifest.html[Number(chapterId)] = filename;
        }
      } else {
        // It's HTML text
        const filename = `chapter_${chapterId}.html`;
        contentFolder.file(filename, contentData);
        manifest.html[Number(chapterId)] = filename;
      }
    }
  }

  // Add manifest
  zip.file("manifest.json", JSON.stringify(manifest, null, 2));

  // Generate Zip
  const content = await zip.generateAsync({ type: "blob" });
  
  // Trigger Download
  const url = URL.createObjectURL(content);
  const link = document.createElement("a");
  link.href = url;
  link.download = `dhamma_guide_package_${new Date().toISOString().slice(0, 10)}.zip`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};

export const importTeachingPackage = async (file: File): Promise<{ 
  images: Record<number, string[]>, 
  diagrams: Record<number, string[]>,
  html: Record<number, string>,
  resources: Record<number, { audio?: string; youtube?: string; questions?: string[]; links?: { title: string; url: string }[] }>,
  quizzes: Record<number, Quiz>
}> => {
  const zip = await JSZip.loadAsync(file);
  const manifestFile = zip.file("manifest.json");
  
  if (!manifestFile) {
    throw new Error("Invalid Package: manifest.json not found");
  }

  const manifestStr = await manifestFile.async("text");
  const parsedManifest = JSON.parse(manifestStr);

  const result = {
    images: {} as Record<number, string[]>,
    diagrams: {} as Record<number, string[]>,
    html: {} as Record<number, string>,
    resources: {} as Record<number, { audio?: string; youtube?: string; questions?: string[]; links?: { title: string; url: string }[] }>,
    quizzes: {} as Record<number, Quiz>
  };

  const isNewFormat = 'infographics' in parsedManifest || 'diagrams' in parsedManifest;
  const infographicMap = isNewFormat ? parsedManifest.infographics : parsedManifest;
  
  let diagramMap: Record<number, string | string[]> = {};
  if (isNewFormat) diagramMap = parsedManifest.diagrams;
  
  const htmlMap = parsedManifest.html || {};
  const resourceMap = parsedManifest.resources || {};
  const quizMap = parsedManifest.quizzes || {};

  // 1. Load Infographics
  for (const [chapterId, filenames] of Object.entries(infographicMap)) {
    const images: string[] = [];
    // @ts-ignore
    for (const filename of filenames) {
      const imagePath = `chapter_${chapterId}/${filename}`;
      const imageFile = zip.file(imagePath);
      if (imageFile) {
        const base64Content = await imageFile.async("base64");
        const ext = filename.split('.').pop()?.toLowerCase();
        let mimeType = 'image/png';
        if (ext === 'jpg' || ext === 'jpeg') mimeType = 'image/jpeg';
        images.push(`data:${mimeType};base64,${base64Content}`);
      }
    }
    result.images[Number(chapterId)] = images;
  }

  // 2. Load Diagrams
  if (diagramMap) {
    for (const [chapterId, fileOrFiles] of Object.entries(diagramMap)) {
      const diagrams: string[] = [];
      const filenames = Array.isArray(fileOrFiles) ? fileOrFiles : [fileOrFiles]; 

      for (const filename of filenames) {
        // @ts-ignore
        const imagePath = `diagrams/${filename}`;
        const imageFile = zip.file(imagePath);
        if (imageFile) {
          const base64Content = await imageFile.async("base64");
          // @ts-ignore
          const ext = filename.split('.').pop()?.toLowerCase();
          let mimeType = 'image/png';
          if (ext === 'jpg' || ext === 'jpeg') mimeType = 'image/jpeg';
          if (ext === 'pdf') mimeType = 'application/pdf'; // Handle PDF restore
          
          diagrams.push(`data:${mimeType};base64,${base64Content}`);
        }
      }
      result.diagrams[Number(chapterId)] = diagrams;
    }
  }

  // 3. Load HTML or PDF Content
  if (htmlMap) {
    for (const [chapterId, filename] of Object.entries(htmlMap)) {
      // @ts-ignore
      const contentPath = `content/${filename}`;
      const contentFile = zip.file(contentPath);
      
      if (contentFile) {
        // @ts-ignore
        if (filename.endsWith('.pdf')) {
          // Load as PDF Data URI
          const base64Pdf = await contentFile.async("base64");
          result.html[Number(chapterId)] = `data:application/pdf;base64,${base64Pdf}`;
        } else {
          // Load as HTML Text
          const htmlContent = await contentFile.async("text");
          result.html[Number(chapterId)] = htmlContent;
        }
      }
    }
  }

  // 4. Load Resources
  result.resources = resourceMap;

  // 5. Load Quizzes
  result.quizzes = quizMap;

  return result;
};
