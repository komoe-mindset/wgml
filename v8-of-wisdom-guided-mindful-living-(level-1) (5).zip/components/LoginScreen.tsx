
import React, { useState, useEffect, useRef } from 'react';
import { GraduationCap, Lock, ArrowRight, UserCog, AlertCircle, Flower, Upload, BookOpen, Globe, Loader2, CheckCircle, XCircle, FileText, HelpCircle, ChevronRight, Info, Download, Monitor, WifiOff } from 'lucide-react';

interface Props {
  onLogin: (role: 'teacher' | 'student') => void;
  onImport: (file: File) => Promise<boolean>;
  language: 'my' | 'en';
  onToggleLanguage: () => void;
  onOpenGuide: () => void;
  installPrompt?: any;
  onInstallApp?: () => void;
}

type ImportStatus = 'idle' | 'processing' | 'success' | 'error';

const COURSE_OUTLINE = [
  { my: "၁။ ကုသိုလ်နှင့်အကုသိုလ်", en: "1. Wisdom in the dimension of merit and demerit" },
  { my: "၂။ ကံကုသိုလ်နှင့်ဉာဏ်ကုသိုလ်", en: "2. Wisdom in the dimension of action-insight relation (karma and Nana)" },
  { my: "၃။ သီလ၊ သမာဓိ၊ ပညာနဲ့ ပြည့်စုံတဲ့ဘဝ", en: "3. Wisdom in the dimension of Sila, Samadhi, Panna (system, power, action)" },
  { my: "၄။ ရှေ့စိတ်-ဓမ္မ၊ နောက်စိတ်-လောက", en: "4. Wisdom in the dimension of previous mind and following mind" },
  { my: "၅။ ဆင်းရဲချမ်းသာ-ဝေဒနာ", en: "5. Wisdom in the dimension of feeling beyond poor and rich" },
  { my: "၆။ မှတ်သားမှုသဘော-သညာ", en: "6. Wisdom in the dimension of perception (identity and reality)" },
  { my: "၇။ ပစ္စုပ္ပန်နှင့်ဉာဏ်", en: "7. Wisdom in the dimension of present and insight" },
  { my: "၈။ ရုပ်နာမ်နှင့်ကိလေသာ", en: "8. Wisdom in the dimension of defilement and process of mind and body" },
  { my: "၉။ သတိနှင့်ဥပါဒါန်", en: "9. Wisdom in the dimension of attachment and mindfulness" }
];

export const LoginScreen: React.FC<Props> = ({ onLogin, onImport, language, onToggleLanguage, onOpenGuide, installPrompt, onInstallApp }) => {
  const [activeTab, setActiveTab] = useState<'selection' | 'teacher-auth'>('selection');
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [storedPin, setStoredPin] = useState('1234');
  const [importStatus, setImportStatus] = useState<ImportStatus>('idle');
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const savedPin = localStorage.getItem('teacher_pin');
    if (savedPin) setStoredPin(savedPin);
  }, []);

  const handleTeacherLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (pin === storedPin) {
      onLogin('teacher');
    } else {
      setError(language === 'my' ? 'စကားဝှက်မှားယွင်းနေပါသည်' : 'Incorrect PIN');
      setPin('');
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImportStatus('processing');
      // Small delay to ensure modal renders
      await new Promise(resolve => setTimeout(resolve, 100));
      
      const success = await onImport(file);
      setImportStatus(success ? 'success' : 'error');
      
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-0 md:p-4 relative">
      
      {/* Import Status Modal */}
      {importStatus !== 'idle' && (
        <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-6" role="dialog" aria-modal="true">
            <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-8 text-center animate-in zoom-in-95 duration-200">
                {importStatus === 'processing' && (
                  <>
                      <div className="w-20 h-20 bg-indigo-50 rounded-full flex items-center justify-center mx-auto mb-6 relative">
                          <Loader2 className="w-10 h-10 text-indigo-600 animate-spin" />
                          <div className="absolute inset-0 rounded-full border-4 border-indigo-100 border-t-indigo-600 animate-spin opacity-50"></div>
                      </div>
                      <h3 className="text-xl font-bold text-slate-800 mb-2 font-burmese">{language === 'my' ? 'ထည့်သွင်းနေသည်...' : 'Importing Package...'}</h3>
                      <p className="text-sm text-slate-600 font-burmese">{language === 'my' ? 'ကျေးဇူးပြု၍ ခေတ္တစောင့်ပါ' : 'Unpacking course materials. This may take a moment.'}</p>
                  </>
                )}

                {importStatus === 'success' && (
                  <>
                      <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-6">
                          <CheckCircle className="w-10 h-10 text-green-600 animate-bounce" />
                      </div>
                      <h3 className="text-xl font-bold text-slate-800 mb-2 font-burmese">{language === 'my' ? 'အောင်မြင်ပါသည်' : 'Import Complete!'}</h3>
                      <p className="text-sm text-slate-600 mb-6 font-burmese">{language === 'my' ? 'သင်ခန်းစာများ ထည့်သွင်းပြီးပါပြီ' : 'Course materials are ready to use.'}</p>
                      <button 
                        onClick={() => setImportStatus('idle')}
                        className="w-full py-3 bg-green-600 hover:bg-green-700 text-white rounded-xl font-bold transition-all active:scale-95"
                      >
                         {language === 'my' ? 'ပြီးပြီ' : 'Done'}
                      </button>
                  </>
                )}

                {importStatus === 'error' && (
                  <>
                      <div className="w-20 h-20 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-6">
                          <XCircle className="w-10 h-10 text-red-600" />
                      </div>
                      <h3 className="text-xl font-bold text-slate-800 mb-2 font-burmese">{language === 'my' ? 'မအောင်မြင်ပါ' : 'Import Failed'}</h3>
                      <p className="text-sm text-slate-600 mb-6 font-burmese">{language === 'my' ? 'ဖိုင်ကို စစ်ဆေးပြီး ပြန်ကြိုးစားပါ' : 'Could not load the package. Please check the file format.'}</p>
                      <button 
                        onClick={() => setImportStatus('idle')}
                        className="w-full py-3 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl font-bold transition-all active:scale-95"
                      >
                         {language === 'my' ? 'ပြန်ကြိုးစားမည်' : 'Close'}
                      </button>
                  </>
                )}
            </div>
        </div>
      )}

      <div className="max-w-6xl w-full bg-white md:rounded-2xl shadow-2xl overflow-hidden flex flex-col md:flex-row min-h-screen md:min-h-0 md:h-[800px] md:max-h-[90vh]">
        
        {/* Left Side: Branding & Objectives - HIDDEN ON MOBILE FOR PERFORMANCE */}
        <div className="hidden md:flex md:w-5/12 bg-gradient-to-br from-indigo-800 to-slate-900 text-white flex-col relative overflow-hidden shrink-0">
          <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
             <Flower className="w-96 h-96 -translate-x-1/2 -translate-y-1/2" />
          </div>
          
          <div className="relative z-10 p-6 md:p-8 pt-6 md:pt-8 pb-0 shrink-0">
            <div className="flex flex-row-reverse items-center justify-between">
                <div className="w-14 h-14 bg-white/10 rounded-2xl flex items-center justify-center backdrop-blur-md border border-white/20 shadow-xl ml-4 shrink-0">
                  <Flower className="w-8 h-8 text-indigo-300" />
                </div>
                <div className="text-right flex-1">
                    {language === 'my' ? (
                        <>
                            <h1 className="text-xl lg:text-2xl font-bold font-burmese text-indigo-100 leading-[2.2]">
                            ဉာဏ်ယှဉ်သတိဖြင့်<br/>နေထိုင်ခြင်း
                            </h1>
                            <h2 className="text-sm serif-title text-indigo-300 font-light tracking-wide mt-1 opacity-90">
                            Wisdom-Guided Mindful Living
                            </h2>
                        </>
                    ) : (
                        <>
                            <h1 className="text-xl lg:text-2xl font-bold serif-title text-indigo-100 leading-tight">
                            Wisdom-Guided<br/>Mindful Living
                            </h1>
                            <h2 className="text-sm font-burmese text-indigo-300 font-light tracking-wide mt-2 opacity-90">
                            ဉာဏ်ယှဉ်သတိဖြင့် နေထိုင်ခြင်း
                            </h2>
                        </>
                    )}
                    <div className="inline-block bg-indigo-500/20 border border-indigo-400/30 px-2 py-0.5 rounded-full text-[10px] font-medium tracking-wider text-indigo-200 mt-2">
                    LEVEL 1
                    </div>
                </div>
            </div>
          </div>

          <div className="relative z-10 flex-1 overflow-y-auto custom-scrollbar p-6 md:p-8 pt-6">
            <h3 className="text-indigo-200 font-bold mb-6 uppercase tracking-wider text-xs border-b border-white/10 pb-2 sticky top-0 bg-gradient-to-br from-indigo-800 to-slate-900 z-20">
              {language === 'my' ? "Objectives (ရည်ရွယ်ချက်များ)" : "Course Objectives"}
            </h3>
            <ul className="space-y-6 pb-2">
                <li className="flex gap-4">
                    <span className="flex-shrink-0 w-6 h-6 rounded-full bg-indigo-500/20 flex items-center justify-center text-indigo-300 text-xs font-bold border border-indigo-500/30 mt-1">1</span>
                    <div>
                        {language === 'my' ? (
                            <>
                                <p className="font-burmese text-white text-base leading-relaxed mb-1">မြတ်စွာဘုရား၏သာသနာကို သာမန်လူတို့ လွယ်ကူစွာ နားလည်သိမြင်ရန်</p>
                                <p className="text-indigo-300/70 text-xs leading-snug">To help common people understand Buddha’s Teachings easily</p>
                            </>
                        ) : (
                            <>
                                <p className="text-white text-sm font-bold leading-relaxed mb-1">To help common people understand Buddha’s Teachings easily</p>
                                <p className="text-indigo-300/70 text-xs font-burmese leading-snug">မြတ်စွာဘုရား၏သာသနာကို သာမန်လူတို့ လွယ်ကူစွာ နားလည်သိမြင်ရန်</p>
                            </>
                        )}
                    </div>
                </li>
                <li className="flex gap-4">
                    <span className="flex-shrink-0 w-6 h-6 rounded-full bg-indigo-500/20 flex items-center justify-center text-indigo-300 text-xs font-bold border border-indigo-500/30 mt-1">2</span>
                    <div>
                        {language === 'my' ? (
                            <>
                                <p className="font-burmese text-white text-base leading-relaxed mb-1">ဓမ္မကို ဘဝမှာ လက်တွေ့ကျင့်သုံး နေထိုင်တတ်ရန်</p>
                                <p className="text-indigo-300/70 text-xs leading-snug">To apply Teachings in daily life</p>
                            </>
                        ) : (
                            <>
                                <p className="text-white text-sm font-bold leading-relaxed mb-1">To apply Teachings in daily life</p>
                                <p className="text-indigo-300/70 text-xs font-burmese leading-snug">ဓမ္မကို ဘဝမှာ လက်တွေ့ကျင့်သုံး နေထိုင်တတ်ရန်</p>
                            </>
                        )}
                    </div>
                </li>
                <li className="flex gap-4">
                    <span className="flex-shrink-0 w-6 h-6 rounded-full bg-indigo-500/20 flex items-center justify-center text-indigo-300 text-xs font-bold border border-indigo-500/30 mt-1">3</span>
                    <div>
                        {language === 'my' ? (
                             <>
                                <p className="font-burmese text-white text-base leading-relaxed mb-1">သာသနာ့အမွေကို လက်ဆင့်ကမ်း မျှဝေပေးရန်</p>
                                <p className="text-indigo-300/70 text-xs leading-snug">To pass on Teachings to future generations</p>
                             </>
                        ) : (
                             <>
                                <p className="text-white text-sm font-bold leading-relaxed mb-1">To pass on Teachings to future generations</p>
                                <p className="text-indigo-300/70 text-xs font-burmese leading-snug">သာသနာ့အမွေကို လက်ဆင့်ကမ်း မျှဝေပေးရန်</p>
                             </>
                        )}
                    </div>
                </li>
            </ul>
          </div>
          
          {/* Desktop PWA Install Footer */}
          {installPrompt && (
              <div className="relative z-20 p-6 border-t border-white/10 bg-slate-900/50 backdrop-blur-md animate-in slide-in-from-bottom-4">
                  <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-lg bg-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0 border border-emerald-500/30">
                          <Download className="w-5 h-5" />
                      </div>
                      <div className="flex-1">
                          <h4 className={`text-white font-bold text-sm ${language === 'my' ? 'font-burmese' : ''}`}>
                              {language === 'my' ? 'ကွန်ပျူတာတွင် ထည့်သွင်းပါ' : 'Install on Desktop'}
                          </h4>
                          <div className="flex items-center gap-1.5 text-xs text-indigo-200 mt-0.5 opacity-80">
                               <WifiOff className="w-3 h-3" />
                               <span className={language === 'my' ? 'font-burmese' : ''}>
                                   {language === 'my' ? 'အင်တာနက်မလိုပါ (Offline)' : 'Offline Supported'}
                               </span>
                          </div>
                      </div>
                      <button 
                          onClick={onInstallApp}
                          aria-label="Install App on Desktop"
                          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg shadow-lg shadow-emerald-900/20 transition-all active:scale-95 whitespace-nowrap"
                      >
                          {language === 'my' ? 'ရယူရန်' : 'Install'}
                      </button>
                  </div>
              </div>
          )}
        </div>

        {/* Right Side: Content & Actions */}
        <div className="w-full md:w-7/12 bg-slate-50 flex flex-col h-full md:h-full overflow-hidden relative border-t md:border-t-0 md:border-l border-slate-200">
          
          {/* Mobile Only Header */}
          <div className="md:hidden bg-indigo-900 text-white p-6 pb-8 relative shrink-0">
             <div className="flex items-center gap-3 relative z-10">
                 <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center backdrop-blur-md border border-white/20 shadow-lg">
                     <Flower className="w-6 h-6 text-indigo-200" />
                 </div>
                 <div>
                     <h1 className={`font-bold text-lg leading-tight ${language === 'my' ? 'font-burmese' : ''}`}>
                         {language === 'my' ? 'ဉာဏ်ယှဉ်သတိဖြင့် နေထိုင်ခြင်း' : 'Wisdom-Guided Mindful Living'}
                     </h1>
                     <p className="text-xs text-indigo-300 opacity-90 font-medium">Level 1 Course</p>
                 </div>
             </div>
             {/* Decorative background element */}
             <div className="absolute top-0 right-0 w-32 h-32 opacity-10 pointer-events-none">
                  <Flower className="w-full h-full -translate-y-1/2 translate-x-1/2" />
             </div>
          </div>

          {/* Mobile PWA Install Banner */}
          {installPrompt && (
             <div className="md:hidden bg-emerald-50 border-b border-emerald-100 p-3 flex items-center justify-between shrink-0 animate-in slide-in-from-top">
                 <div className="flex items-center gap-2">
                     <div className="p-1.5 bg-emerald-100 rounded-lg text-emerald-600"><Download className="w-4 h-4" /></div>
                     <div>
                         <p className="text-xs font-bold text-emerald-800">Install App</p>
                         <p className="text-[10px] text-emerald-700 font-medium">Faster load times & offline use</p>
                     </div>
                 </div>
                 <button onClick={onInstallApp} aria-label="Install App" className="px-3 py-1.5 bg-emerald-600 text-white text-xs font-bold rounded-lg shadow-sm active:scale-95">
                     Install
                 </button>
             </div>
          )}

          {activeTab === 'selection' && (
            <div className="flex flex-col h-full animate-in fade-in duration-500">
                {/* Top Action Bar */}
                <div className="bg-white border-b border-slate-200 p-4 md:p-5 shadow-[0_4px_20px_rgba(0,0,0,0.03)] z-20 shrink-0 -mt-4 md:mt-0 rounded-t-2xl md:rounded-none">
                    {/* Header Row: Title & Top Controls */}
                    <div className="flex justify-between items-start mb-4">
                         <div>
                            <h2 className="text-lg md:text-xl font-bold text-slate-800">
                                {language === 'my' ? 'ကြိုဆိုပါသည်' : 'Welcome'}
                            </h2>
                            <p className="text-xs text-slate-500 font-medium">
                                {language === 'my' ? 'ဆက်လက်လေ့လာရန် ရွေးချယ်ပါ' : 'Select an option to continue'}
                            </p>
                        </div>
                        
                        <div className="flex gap-2 items-center">
                            {/* Import Button moved to header */}
                            <button 
                                onClick={() => fileInputRef.current?.click()}
                                disabled={importStatus === 'processing'}
                                aria-label="Import Package"
                                className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-600 rounded-full text-xs font-bold transition-all border border-indigo-100 disabled:opacity-50"
                                title="Import Package"
                            >
                                <Upload className="w-3.5 h-3.5" />
                                <span className="hidden sm:inline">{language === 'my' ? 'ဖိုင်ထည့်ရန်' : 'Import'}</span>
                            </button>
                            <input 
                                type="file" 
                                ref={fileInputRef} 
                                onChange={handleFileChange} 
                                className="hidden" 
                                accept=".zip"
                            />

                            <button 
                                onClick={onOpenGuide}
                                aria-label="User Guide"
                                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-full text-xs font-bold transition-all border border-slate-200"
                                title="User Guide"
                            >
                                <HelpCircle className="w-3.5 h-3.5" />
                                <span className="hidden sm:inline">{language === 'my' ? 'လမ်းညွှန်' : 'Guide'}</span>
                            </button>
                            
                            <button 
                                onClick={onToggleLanguage}
                                aria-label="Toggle Language"
                                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-full text-xs font-bold transition-all border border-slate-200"
                            >
                                <Globe className="w-3.5 h-3.5" />
                                <span>{language === 'my' ? 'MY' : 'EN'}</span>
                            </button>
                        </div>
                    </div>

                    {/* Main Actions (Split 50/50 Row) */}
                    <div className="flex gap-3">
                        {/* Student Login - Primary - Left Half */}
                        <button 
                            onClick={() => onLogin('student')}
                            aria-label="Student Login"
                            className="flex-1 group bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 hover:border-emerald-300 p-3 rounded-xl transition-all flex items-center gap-3 relative overflow-hidden shadow-sm hover:shadow-md"
                        >
                            <div className="w-10 h-10 bg-emerald-200 rounded-full flex items-center justify-center text-emerald-800 shadow-inner shrink-0">
                                <GraduationCap className="w-5 h-5" />
                            </div>
                            <div className="text-left">
                                <span className={`block font-bold text-slate-800 text-sm ${language === 'my' ? 'font-burmese' : ''}`}>
                                    {language === 'my' ? 'ကျောင်းသား' : 'Student'}
                                </span>
                                <span className="text-[10px] text-emerald-700 font-bold block">Start Learning &rarr;</span>
                            </div>
                        </button>

                        {/* Teacher Login - Secondary - Right Half */}
                        <button 
                            onClick={() => setActiveTab('teacher-auth')}
                            aria-label="Teacher Login"
                            className="flex-1 group bg-white hover:bg-slate-50 border border-slate-200 hover:border-slate-300 p-3 rounded-xl transition-all flex items-center gap-3 shadow-sm hover:shadow-md"
                        >
                            <div className="w-10 h-10 bg-slate-100 group-hover:bg-slate-200 rounded-full flex items-center justify-center text-slate-500 group-hover:text-indigo-600 transition-colors shrink-0">
                                <UserCog className="w-5 h-5" />
                            </div>
                            <div className="text-left">
                                <span className={`block font-bold text-slate-700 text-sm ${language === 'my' ? 'font-burmese' : ''}`}>
                                    {language === 'my' ? 'ဆရာ' : 'Teacher'}
                                </span>
                                <span className="text-[10px] text-slate-500 font-medium block">Login Access</span>
                            </div>
                        </button>
                    </div>
                </div>

                {/* Scrollable Course List - Maximized Space */}
                <div className="flex-1 overflow-y-auto custom-scrollbar p-6 md:p-8 pt-4 md:pt-6 bg-slate-50/50">
                    <div className="flex items-center gap-2 mb-4 sticky top-0 bg-slate-50/95 backdrop-blur-sm py-2 z-10 border-b border-transparent">
                        <BookOpen className="w-4 h-4 text-indigo-600" />
                        <h2 className={`text-sm font-bold text-slate-600 uppercase tracking-wider ${language === 'my' ? 'font-burmese' : ''}`}>
                            {language === 'my' ? "သင်ခန်းစာများ (Curriculum)" : "Curriculum Overview"}
                        </h2>
                    </div>
                    
                    <div className="space-y-3 pb-4">
                        {COURSE_OUTLINE.map((item, idx) => (
                        <div key={idx} className="bg-white p-3 md:p-4 rounded-xl border border-slate-200 shadow-[0_2px_4px_rgba(0,0,0,0.02)] hover:border-indigo-200 transition-colors flex gap-3">
                             <div className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center text-[10px] font-bold text-slate-600 mt-1 shrink-0">
                                {idx + 1}
                             </div>
                             <div>
                                {language === 'my' ? (
                                    <>
                                        <h3 className="font-bold text-slate-800 font-burmese text-base leading-[2.4]">{item.my}</h3>
                                        <p className="text-xs text-slate-600 mt-1 font-medium">{item.en}</p>
                                    </>
                                ) : (
                                    <>
                                        <h3 className="font-bold text-slate-800 text-sm leading-relaxed">{item.en}</h3>
                                        <p className="text-xs text-slate-500 mt-1 font-burmese">{item.my}</p>
                                    </>
                                )}
                             </div>
                        </div>
                        ))}
                    </div>
                </div>
            </div>
          )}

          {activeTab === 'teacher-auth' && (
            <div className="flex flex-col h-full items-center justify-center p-8 animate-in slide-in-from-right-10 duration-300 bg-white">
               <button 
                onClick={() => { setActiveTab('selection'); setError(''); setPin(''); }}
                aria-label="Back"
                className="absolute top-6 left-6 text-sm text-slate-600 hover:text-indigo-600 flex items-center gap-2 group font-medium"
               >
                 <span className="group-hover:-translate-x-1 transition-transform">←</span> {language === 'my' ? 'နောက်သို့' : 'Back'}
               </button>

               <div className="w-full max-w-xs">
                 <div className="text-center mb-8">
                   <div className="w-16 h-16 bg-indigo-100 rounded-2xl flex items-center justify-center text-indigo-600 mx-auto mb-4 shadow-inner">
                     <Lock className="w-8 h-8" />
                   </div>
                   <h2 className="text-xl font-bold text-slate-800 font-burmese">{language === 'my' ? 'PIN ကုဒ်ရိုက်ထည့်ပါ' : 'Enter PIN'}</h2>
                   <p className="text-sm text-slate-600 mt-1">{language === 'my' ? 'ဆရာများအတွက်သာ' : 'For Teacher Access'}</p>
                 </div>

                 <form onSubmit={handleTeacherLogin} className="space-y-6">
                   <div>
                       <label htmlFor="pin-input" className="sr-only">Enter PIN</label>
                       <input
                         id="pin-input"
                         type="password"
                         value={pin}
                         onChange={(e) => setPin(e.target.value)}
                         className="w-full text-center text-3xl font-bold tracking-[0.5em] p-4 rounded-xl border-2 border-slate-200 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all placeholder:tracking-normal bg-white text-slate-900"
                         placeholder="••••"
                         maxLength={8}
                         autoFocus
                       />
                   </div>
                   
                   {error && (
                     <div className="flex items-center gap-2 text-red-600 text-xs bg-red-50 p-3 rounded-lg justify-center animate-shake border border-red-100">
                       <AlertCircle className="w-3 h-3 shrink-0" />
                       <span className="font-burmese">{error}</span>
                     </div>
                   )}

                   <button 
                     type="submit"
                     className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3.5 rounded-xl shadow-lg shadow-indigo-500/30 transition-all active:scale-95 flex items-center justify-center gap-2"
                   >
                     <span className="font-burmese">{language === 'my' ? 'ဝင်ရောက်ရန်' : 'Login'}</span>
                   </button>
                 </form>
               </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
