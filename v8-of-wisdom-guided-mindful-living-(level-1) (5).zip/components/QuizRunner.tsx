import React, { useState, useEffect, useRef } from 'react';
import { Quiz } from '../types';
import { ChevronRight, RefreshCw, Trophy, CheckCircle, XCircle, ArrowRight, Eye, ChevronLeft, FileDown, Clock, AlertTriangle } from 'lucide-react';

interface Props {
  quiz: Quiz;
  onExit: () => void;
  chapterTitle?: string;
}

const QUESTION_TIME_LIMIT = 15; // Seconds per question

export const QuizRunner: React.FC<Props> = ({ quiz, onExit, chapterTitle = "Chapter Content" }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<(number | null)[]>(new Array(quiz.questions.length).fill(null));
  const [isFinished, setIsFinished] = useState(false);
  const [isReviewMode, setIsReviewMode] = useState(false);
  const [certificateName, setCertificateName] = useState("");
  
  // Timer State
  const [timeLeft, setTimeLeft] = useState(QUESTION_TIME_LIMIT);
  // Use 'any' to avoid NodeJS.Timeout namespace issues in browser environment
  const timerRef = useRef<any>(null);

  const currentQuestion = quiz.questions[currentIndex];
  // In review mode, we still show the user's selected option if they answered
  const selectedOption = userAnswers[currentIndex];
  // Note: -1 indicates Time Out
  const isAnswered = selectedOption !== null;

  // --- TIMER LOGIC ---
  useEffect(() => {
    // Don't run timer if: Finished, Review Mode, or Question is already answered
    if (isFinished || isReviewMode || isAnswered) {
        if (timerRef.current) clearInterval(timerRef.current);
        return;
    }

    setTimeLeft(QUESTION_TIME_LIMIT); // Reset timer on new question

    timerRef.current = setInterval(() => {
        setTimeLeft((prev) => {
            if (prev <= 1) {
                // Time is up!
                handleTimeout();
                return 0;
            }
            return prev - 1;
        });
    }, 1000);

    return () => {
        if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [currentIndex, isFinished, isReviewMode, isAnswered]);

  const handleTimeout = () => {
      if (timerRef.current) clearInterval(timerRef.current);
      
      // Mark as Time Out (-1)
      const newAnswers = [...userAnswers];
      newAnswers[currentIndex] = -1; 
      setUserAnswers(newAnswers);

      // CHANGED: Removed auto-advance. 
      // User must read explanation and click Next manually.
  };

  const handleOptionClick = (idx: number) => {
    // Disable clicking in Review Mode, if already answered, or if time is 0
    if (isReviewMode || isAnswered || timeLeft === 0) return;
    
    // Stop timer immediately
    if (timerRef.current) clearInterval(timerRef.current);

    const newAnswers = [...userAnswers];
    newAnswers[currentIndex] = idx;
    setUserAnswers(newAnswers);
  };

  const handleNext = (force = false) => {
    // In quiz mode, allow next only if answered (or forced by timeout)
    // In review mode, always allow next
    if (!isReviewMode && !isAnswered && !force) return;

    if (currentIndex < quiz.questions.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setTimeLeft(QUESTION_TIME_LIMIT); // Explicit reset for UI smoothness
    } else {
      // Last question reached
      // Whether in Quiz Mode or Review Mode, we go to the Result/Score screen
      setIsFinished(true);
      if (isReviewMode) {
          setIsReviewMode(false); // Reset review mode to show results purely
      }
    }
  };

  const handlePrevious = () => {
      if (currentIndex > 0) {
          setCurrentIndex(prev => prev - 1);
      }
  };

  const handleRestart = () => {
    setCurrentIndex(0);
    setUserAnswers(new Array(quiz.questions.length).fill(null));
    setIsFinished(false);
    setIsReviewMode(false);
    setCertificateName("");
    setTimeLeft(QUESTION_TIME_LIMIT);
  };

  const startReview = () => {
      setIsReviewMode(true);
      setIsFinished(false);
      setCurrentIndex(0);
  };

  const calculateScore = () => {
      return userAnswers.reduce((acc, ans, idx) => {
          return ans === quiz.questions[idx].correctAnswer ? acc + 1 : acc;
      }, 0);
  };

  const handleDownloadCertificate = () => {
      if (!certificateName.trim()) return;

      try {
        const date = new Date().toLocaleDateString();
        const certificateContent = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Certificate of Achievement</title>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;700&family=Padauk:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body { margin: 0; padding: 0; display: flex; justify-content: center; align-items: center; min-height: 100vh; background-color: #f0f0f0; font-family: 'Cinzel', serif; }
        .certificate-container { position: relative; width: 1000px; height: 700px; background-color: #fffaf0; padding: 40px; box-shadow: 0 10px 30px rgba(0,0,0,0.2); border: 2px solid #b8860b; box-sizing: border-box; display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; }
        .border-inner { position: absolute; top: 20px; left: 20px; right: 20px; bottom: 20px; border: 4px double #b8860b; pointer-events: none; }
        .corner-decoration { position: absolute; width: 50px; height: 50px; border-color: #b8860b; border-style: solid; }
        .top-left { top: 30px; left: 30px; border-width: 4px 0 0 4px; }
        .top-right { top: 30px; right: 30px; border-width: 4px 4px 0 0; }
        .bottom-left { bottom: 30px; left: 30px; border-width: 0 0 4px 4px; }
        .bottom-right { bottom: 30px; right: 30px; border-width: 0 4px 4px 0; }
        .header { font-size: 48px; color: #b8860b; margin-bottom: 20px; text-transform: uppercase; letter-spacing: 4px; font-weight: 700; }
        .sub-header { font-size: 24px; color: #555; margin-bottom: 40px; letter-spacing: 2px; }
        .student-name { font-size: 56px; color: #2c3e50; border-bottom: 2px solid #b8860b; padding-bottom: 10px; margin: 20px 0; display: inline-block; min-width: 400px; font-weight: bold; font-family: 'Padauk', serif; }
        .course-title { font-size: 32px; color: #2c3e50; margin: 30px 0; font-weight: bold; font-family: 'Padauk', serif; }
        .date { font-size: 18px; color: #666; position: absolute; bottom: 80px; left: 80px; }
        .signature { position: absolute; bottom: 80px; right: 80px; border-top: 1px solid #333; width: 200px; padding-top: 10px; font-size: 18px; color: #333; }
        .logo { font-size: 60px; color: #b8860b; margin-bottom: 20px; }
        .watermark { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); opacity: 0.05; font-size: 400px; color: #b8860b; pointer-events: none; z-index: 0; }
        .content { position: relative; z-index: 1; }
        .btn-print { position: fixed; bottom: 20px; right: 20px; padding: 15px 30px; background: #b8860b; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; font-weight: bold; box-shadow: 0 4px 10px rgba(0,0,0,0.3); transition: background 0.3s; }
        .btn-print:hover { background: #8b6508; }
        @media print { body { background: none; } .certificate-container { box-shadow: none; margin: 0; width: 100%; height: 100vh; page-break-after: always; } .btn-print { display: none; } }
    </style>
</head>
<body>
    <div class="certificate-container">
        <div class="border-inner"></div>
        <div class="corner-decoration top-left"></div>
        <div class="corner-decoration top-right"></div>
        <div class="corner-decoration bottom-left"></div>
        <div class="corner-decoration bottom-right"></div>
        <div class="watermark">✿</div>
        
        <div class="content">
            <div class="logo">✿</div>
            <div class="header">Certificate of Achievement</div>
            <div class="sub-header">ဂုဏ်ပြုမှတ်တမ်းလွှာ</div>
            <p style="font-size: 18px; color: #666;">This certifies that (ဤလက်မှတ်ကို)</p>
            <div class="student-name">${certificateName}</div>
            <p style="font-size: 18px; color: #666;">has successfully mastered the wisdom of</p>
            <div class="course-title">${chapterTitle}</div>
            <p style="font-size: 18px; color: #666;">with a perfect score of 100%.</p>
        </div>

        <div class="date">Date: ${date}</div>
        <div class="signature">Wisdom-Guided Mindful Living</div>
    </div>
    <button class="btn-print" onclick="window.print()">🖨️ Print / Save as PDF</button>
</body>
</html>
        `;

        const blob = new Blob([certificateContent], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        const safeTitle = chapterTitle.replace(/[^a-z0-9]/gi, '_');
        link.download = `Certificate_${safeTitle}.html`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
      } catch (e) {
        console.error("Certificate generation error:", e);
        alert("Failed to generate certificate. Please try again.");
      }
  };

  if (isFinished) {
    const score = calculateScore();
    const percentage = Math.round((score / quiz.questions.length) * 100);
    const isPerfectScore = percentage === 100;

    return (
      <div className="h-full flex flex-col items-center justify-center p-6 bg-slate-50 text-center animate-in fade-in zoom-in-95 duration-300">
        <div className={`w-24 h-24 rounded-full flex items-center justify-center mb-6 shadow-lg ${isPerfectScore ? 'bg-yellow-100 text-yellow-600' : 'bg-indigo-100 text-indigo-600'}`}>
           <Trophy className="w-12 h-12" />
        </div>
        <h2 className="text-3xl font-bold font-burmese text-slate-800 mb-2">Quiz Complete!</h2>
        <p className="text-slate-500 mb-6 font-burmese">သင်၏ရမှတ် (Your Score)</p>
        
        <div className={`text-6xl font-black mb-2 ${isPerfectScore ? 'text-yellow-600' : 'text-indigo-600'}`}>{percentage}%</div>
        <p className="text-slate-600 mb-8 font-medium">{score} out of {quiz.questions.length} Correct</p>

        {isPerfectScore && (
            <div className="mb-6 animate-bounce">
                <span className="inline-block px-4 py-1 rounded-full bg-yellow-100 text-yellow-700 text-sm font-bold border border-yellow-300">
                    🎉 Perfect Score! You can now download your certificate.
                </span>
            </div>
        )}

        <div className="flex flex-col gap-3 w-full max-w-xs">
          {isPerfectScore && (
            <div className="w-full mb-2">
                <label className="block text-left text-xs font-bold text-slate-500 mb-1 ml-1 uppercase">Name on Certificate</label>
                <input 
                    type="text" 
                    value={certificateName}
                    onChange={(e) => setCertificateName(e.target.value)}
                    placeholder="Enter your name..."
                    className="w-full p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-yellow-500 outline-none text-center font-bold text-slate-700 shadow-sm"
                    autoFocus
                />
            </div>
          )}

          {isPerfectScore && (
               <button 
                 onClick={handleDownloadCertificate}
                 disabled={!certificateName.trim()}
                 className="w-full py-3.5 bg-gradient-to-r from-yellow-500 to-amber-600 hover:from-yellow-600 hover:to-amber-700 text-white rounded-xl font-bold shadow-lg shadow-yellow-500/30 active:scale-95 transition-all flex items-center justify-center gap-2 mb-2 disabled:opacity-50 disabled:cursor-not-allowed disabled:shadow-none"
               >
                 <FileDown className="w-5 h-5" /> Download Certificate
               </button>
          )}

          <button 
            onClick={startReview}
            className="w-full py-3 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 rounded-xl font-bold border border-indigo-200 transition-all flex items-center justify-center gap-2"
          >
            <Eye className="w-5 h-5" /> Review Answers
          </button>
          <button 
            onClick={handleRestart}
            className="w-full py-3 bg-indigo-600 text-white rounded-xl font-bold shadow-lg shadow-indigo-200 active:scale-95 transition-all flex items-center justify-center gap-2"
          >
            <RefreshCw className="w-5 h-5" /> Try Again
          </button>
          <button 
            onClick={onExit}
            className="w-full py-3 bg-white text-slate-600 border border-slate-200 rounded-xl font-bold hover:bg-slate-50 transition-colors"
          >
            Exit Quiz
          </button>
        </div>
      </div>
    );
  }

  // --- UI Helpers for Timer ---
  const getTimerColor = () => {
      if (timeLeft > 10) return 'bg-emerald-500';
      if (timeLeft > 5) return 'bg-yellow-500';
      return 'bg-red-500 animate-pulse';
  };

  const getTimerWidth = () => {
      return `${(timeLeft / QUESTION_TIME_LIMIT) * 100}%`;
  };

  return (
    <div className="h-full flex flex-col bg-white overflow-hidden relative">
      {/* Timer Bar (Only in Quiz Mode) */}
      {!isReviewMode && !isAnswered && (
          <div className="h-2 w-full bg-slate-100">
              <div 
                className={`h-full transition-all duration-1000 linear ${getTimerColor()}`}
                style={{ width: getTimerWidth() }}
              />
          </div>
      )}

      {/* Review Mode Banner */}
      {isReviewMode && (
          <div className="bg-yellow-50 border-b border-yellow-200 p-2 text-center text-xs font-bold text-yellow-800 flex items-center justify-center gap-2">
              <Eye className="w-4 h-4"/> You are reviewing your answers.
          </div>
      )}

      {/* Time's Up Banner */}
      {selectedOption === -1 && !isReviewMode && (
           <div className="bg-orange-500 text-white p-2 text-center text-sm font-bold flex items-center justify-center gap-2 animate-in slide-in-from-top">
               <AlertTriangle className="w-4 h-4" /> Time's Up! Check the explanation below, then click Next.
           </div>
      )}

      {/* Header */}
      <div className="p-4 flex justify-between items-center border-b border-slate-50">
        <div className="text-xs font-bold text-slate-500 flex items-center gap-3">
            <span>Question {currentIndex + 1}/{quiz.questions.length}</span>
            {/* Countdown Clock */}
            {!isReviewMode && !isAnswered && (
                <div className={`flex items-center gap-1 px-2 py-0.5 rounded-full ${timeLeft <= 5 ? 'text-red-600 bg-red-50' : 'text-slate-600 bg-slate-100'}`}>
                    <Clock className="w-3.5 h-3.5" />
                    <span className="tabular-nums">00:{timeLeft.toString().padStart(2, '0')}</span>
                </div>
            )}
        </div>
        <div className="flex gap-2 text-xs font-bold">
            {isReviewMode && <button onClick={() => { setIsFinished(true); setIsReviewMode(false); }} className="text-indigo-600 hover:text-indigo-800 p-1 underline">Back to Score</button>}
            <button onClick={onExit} className="text-slate-400 hover:text-slate-600 p-1">Exit</button>
        </div>
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto p-4 pb-24 custom-scrollbar">
        {/* Question */}
        <h3 className="text-lg md:text-xl font-bold text-slate-800 font-burmese leading-[2.4] mb-6 animate-in fade-in slide-in-from-right-4 duration-300">
          {currentQuestion.question}
        </h3>

        {/* Options */}
        <div className="space-y-3">
          {currentQuestion.options.map((option, idx) => {
            let stateClass = "border-slate-200 bg-white hover:border-indigo-300";
            
            if (isReviewMode) {
                // REVIEW MODE LOGIC
                if (idx === currentQuestion.correctAnswer) {
                    stateClass = "border-green-500 bg-green-50 text-green-900 ring-1 ring-green-500 font-bold";
                } else if (idx === selectedOption) {
                    stateClass = "border-red-500 bg-red-50 text-red-900 ring-1 ring-red-500 font-bold opacity-100";
                } else {
                    stateClass = "border-slate-100 bg-slate-50 text-slate-400 opacity-50";
                }
            } else {
                // QUIZ MODE LOGIC (Immediate Feedback)
                if (isAnswered) {
                    if (idx === currentQuestion.correctAnswer) stateClass = "border-green-500 bg-green-50 text-green-800 ring-1 ring-green-500";
                    else if (idx === selectedOption) stateClass = "border-red-500 bg-red-50 text-red-800 ring-1 ring-red-500";
                    else stateClass = "border-slate-100 bg-slate-50 opacity-60";
                } else if (selectedOption === idx) {
                    stateClass = "border-indigo-500 bg-indigo-50 ring-1 ring-indigo-500";
                }
            }

            return (
              <button
                key={idx}
                onClick={() => handleOptionClick(idx)}
                disabled={isAnswered || isReviewMode}
                className={`w-full text-left p-4 rounded-xl border-2 transition-all duration-200 font-burmese leading-loose text-base flex items-start gap-3 ${stateClass} ${!isAnswered && !isReviewMode ? 'active:scale-[0.98]' : ''}`}
              >
                <span className={`w-6 h-6 flex items-center justify-center rounded-full text-xs font-bold border shrink-0 mt-1 
                    ${(isReviewMode && idx === currentQuestion.correctAnswer) || (isAnswered && !isReviewMode && idx === currentQuestion.correctAnswer) ? 'bg-green-500 text-white border-green-500' : 
                      (isReviewMode && idx === selectedOption && idx !== currentQuestion.correctAnswer) ? 'bg-red-500 text-white border-red-500' :
                      'bg-slate-100 text-slate-500 border-slate-300'}
                `}>
                  {String.fromCharCode(65 + idx)}
                </span>
                {option}
              </button>
            );
          })}
        </div>

        {/* Feedback Area (Show if answered OR in review mode) */}
        {(isAnswered || isReviewMode) && (
          <div className={`mt-6 p-4 rounded-xl border animate-in slide-in-from-bottom-2 fade-in ${selectedOption === currentQuestion.correctAnswer ? 'bg-green-50 border-green-200' : 'bg-orange-50 border-orange-200'}`}>
             <div className="flex items-center gap-2 mb-2 font-bold">
                {selectedOption === currentQuestion.correctAnswer ? (
                    <><CheckCircle className="w-5 h-5 text-green-600"/> <span className="text-green-700">Correct!</span></>
                ) : selectedOption === -1 ? (
                    <><AlertTriangle className="w-5 h-5 text-orange-600"/> <span className="text-orange-700">Time's Up - Missed</span></>
                ) : (
                    <><XCircle className="w-5 h-5 text-red-600"/> <span className="text-red-700">Incorrect</span></>
                )}
             </div>
             <p className="text-sm font-burmese leading-relaxed text-slate-700">
               {currentQuestion.explanation}
             </p>
          </div>
        )}
      </div>

      {/* Footer Action */}
      <div className="p-4 bg-white border-t border-slate-100 absolute bottom-0 left-0 right-0 z-10 flex gap-3">
        {isReviewMode && (
             <button 
                onClick={handlePrevious}
                disabled={currentIndex === 0}
                className="w-1/3 py-3.5 bg-slate-100 text-slate-600 rounded-xl font-bold hover:bg-slate-200 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
             >
                <ChevronLeft className="w-5 h-5" /> Prev
             </button>
        )}
        <button 
          onClick={() => handleNext(false)} 
          disabled={!isAnswered && !isReviewMode}
          className="flex-1 py-3.5 bg-indigo-600 text-white rounded-xl font-bold shadow-lg shadow-indigo-200 disabled:opacity-50 disabled:shadow-none transition-all flex items-center justify-center gap-2"
        >
          {currentIndex === quiz.questions.length - 1 ? (isReviewMode ? 'Finish Review' : 'Finish Quiz') : 'Next Question'}
          <ArrowRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};