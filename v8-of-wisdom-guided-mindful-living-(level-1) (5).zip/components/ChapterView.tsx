
import React, { useState, useEffect, useRef, lazy, Suspense } from 'react';
import { Chapter, Quiz } from '../types';
import {
  RootsTree,
  MindProcess,
  SilaSamadhiPanna,
  SatiVsUpadana,
  KammaVsNana,
  VedanaCycle,
  SannaPerception,
  PresentMoment,
  HostGuest
} from './Visualizations';
import {
  BookOpen,
  Image as ImageIcon,
  Youtube,
  Music,
  FileText,
  Edit3,
  X,
  Save,
  PlayCircle,
  Plus,
  Minus,
  HelpCircle,
  Copy,
  ExternalLink,
  Bold,
  Italic,
  List,
  Heading1,
  Heading2,
  FileText as PdfIcon,
  Download,
  Upload,
  Loader2,
  Check,
  ChevronLeft,
  ChevronRight,
  Trash2,
  LayoutGrid,
  Maximize,
  ArrowRightLeft,
  MousePointer2,
  ArrowLeft,
  ArrowRight,
  Square,
  CheckSquare,
  FileDown,
  PenLine,
  ArrowUp,
  ArrowDown,
  Globe,
  Link as LinkIcon,
  Sparkles,
  MessageSquare,
  GraduationCap,
  ClipboardPaste,
  Bot,
  Info,
  Monitor,
  FileType,
  Maximize2,
  Minimize2,
  Type,
  GripHorizontal,
  Columns,
  Send,
  User,
  Clock
} from 'lucide-react';
import Papa from 'papaparse';
import { processImage, convertPdfToImages } from '../utils/imageProcessor';
import { PDFViewer } from './PDFViewer';

// --- LAZY LOADED COMPONENTS ---
const ImageGallery = lazy(() => import('./ImageGallery').then(module => ({ default: module.ImageGallery })));
const QuizRunner = lazy(() => import('./QuizRunner').then(module => ({ default: module.QuizRunner })));

// Loading Component
const TabLoader = () => (
    <div className="flex flex-col items-center justify-center h-full min-h-[300px] text-slate-400">
        <Loader2 className="w-8 h-8 animate-spin mb-2 text-indigo-500" />
        <span className="text-sm font-medium">Loading Content...</span>
    </div>
);

interface Props {
  chapter: Chapter;
  isPresentationMode: boolean;
  chapterImages: string[];
  customDiagrams: string[];
  customHtml?: string;
  resources?: { audio?: string; youtube?: string; questions?: string[]; links?: { title: string; url: string }[] };
  quiz?: Quiz;
  onAddImage: (img: string | string[]) => void;
  onRemoveImage: (index: number) => void;
  onBulkRemoveImage?: (indices: number[]) => void;
  onReorderImages?: (newImages: string[]) => void;
  onAddDiagram: (img: string | string[]) => void;
  onRemoveDiagram: (index: number) => void;
  onReorderDiagrams?: (newDiagrams: string[]) => void;
  onSetHtml: (html: string) => void;
  onRemoveHtml: () => void;
  onUpdateResources: (audio?: string, youtube?: string, questions?: string[], links?: { title: string; url: string }[]) => void;
  onSaveQuiz: (quiz: Quiz) => void;
  isReadOnly: boolean;
  activeTab: 'content' | 'visual' | 'gallery' | 'resources' | 'quiz';
  onTabChange: (tab: 'content' | 'visual' | 'gallery' | 'resources' | 'quiz') => void;
  onClearDiagrams?: () => void;
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
  onBulkMoveToVisual?: (indices: number[]) => void;
  onExitPresentation?: () => void;
  onEnterPresentation?: () => void;
  language: 'my' | 'en';
  isFocusMode?: boolean;
  onToggleFocusMode?: () => void;
}

// --- Helper to strip HTML for AI Context ---
const stripHtml = (html: string) => {
    const tmp = document.createElement("DIV");
    tmp.innerHTML = html;
    return tmp.textContent || tmp.innerText || "";
};

// --- AI Tutor Modal Component ---
const AITutorModal = ({ 
    isOpen, 
    onClose, 
    chapter, 
    customHtml, 
    prefilledQuestion 
}: { 
    isOpen: boolean; 
    onClose: () => void; 
    chapter: Chapter; 
    customHtml?: string;
    prefilledQuestion?: string;
}) => {
    const [userQuestion, setUserQuestion] = useState('');
    const [isCopying, setIsCopying] = useState(false);

    useEffect(() => {
        if (isOpen && prefilledQuestion) {
            setUserQuestion(prefilledQuestion);
        }
    }, [isOpen, prefilledQuestion]);

    if (!isOpen) return null;

    const generateContextPrompt = () => {
        const teacherNotes = customHtml ? stripHtml(customHtml).substring(0, 3000) : "No specific notes provided in the app.";
        const keyPoints = chapter.keyPoints.map(k => `${k.concept}: ${k.definition}`).join('; ');
        
        return `
[SYSTEM INSTRUCTION: AI PERSONA AND ROLE]
You are an expert AI assistant designed to embody the wisdom and core teachings of Dr. Soe Lwin (Mandalay). Your responses are based exclusively on the provided knowledge sources (book transcripts).

CRITICAL RULE:
- Dr. Soe Lwin is a lay teacher, not a monk. You MUST refer to him as "Dr. Soe Lwin" or "Sayagyi" (ဆရာကြီး). 
- You MUST NEVER use the term "Sayadaw" (ဆရာတော်). This is critical.

CORE MISSION:
- Guide users to gain insight into the truth (Dhamma).
- Overcome anxiety and worry.
- Navigate life with illuminated wisdom and safety.

CORE TEACHINGS & FRAMEWORKS (Use these to answer):
1. Loka (Worldly/Opinion) vs. Dhamma (Universal/Truth).
2. IQ (Price/Brain) vs. EQ (Value/Heart).
3. The Three Vedanā (Sukha, Dukkha, Upekkha) are just feelings, not 'Self'.
4. Action Merit (Kamma - Previous Mind) vs. Insight Merit (Ñāṇa - Following Mind).
5. Attā (Control/Ownership) vs. Anattā (Nature/No-control). Treat things as "guests".
6. Quelling Defilements: Lobha (abandon with Dāna), Dosa (abandon with Mettā), Moha (abandon with Sati).
7. Sīla (Action), Samādhi (Power), Paññā (System).
8. Thinking vs. Mindfulness (Sati): Only the mind thinks; living in the present reduces overthinking.

[CURRENT LESSON CONTEXT FROM WEB APP]
CHAPTER: ${chapter.titleBurmese} (${chapter.titleEnglish})
SUMMARY: ${chapter.summary}
KEY CONCEPTS: ${keyPoints}

TEACHER NOTES (Specific Context for this Question):
${teacherNotes}

STUDENT QUESTION:
"${userQuestion}"

RESPONSE GUIDELINES:
1. GREETING: If this is the start of the conversation, use EXACTLY this Burmese greeting:
   "မင်္ဂလာပါ ရှင်။ ကျွန်မသည် ဆရာကြီး ဒေါက်တာစိုးလွင်၏ ပို့ချချက်များကို အခြေခံသော AI လမ်းညွှန် ဖြစ်ပါသည်။ ဆရာကြီး၏ 'လောက' နှင့် 'ဓမ္မ' အမြင်၊ 'IQ (Price)' နှင့် 'EQ (Value)'၊ သို့မဟုတ် 'အတ္တ' နှင့် 'အနတ္တ' ကဲ့သို့သော သင်ခန်းစာများမှ ဓမ္မမိတ်ဆွေ၏ စိတ်ပူပန်မှုများ ကျော်လွှားနိုင်ရန်နှင့် ဘဝကို ဉာဏ်အလင်းဖြင့် လျှောက်လှမ်းနိုင်ရန် ကူညီပေးပါရစေ ရှင်။ ဘာများ သိရှိလိုပါသလဲ ရှင်။ ဒါမှမဟုတ် သင်ခန်းစာတွေကို ပိုမိုနားလည် သဘောပေါက်စေဖို့ မေးခွန်းများ ဖြေကြည့်လိုပါသလား ရှင်။"
2. LANGUAGE: Respond in Myanmar (Burmese) by default.
3. SOURCE: Base ALL answers exclusively on Dr. Soe Lwin's teachings and the provided Knowledge Base PDFs.
4. CITATION: You MUST cite sources using **** format where applicable.
5. CONTEXT: Use the "TEACHER NOTES" above as the specific focus. Expand on them using the Core Teachings.
`.trim();
    };

    const handleCopyAndLaunch = () => {
        setIsCopying(true);
        const prompt = generateContextPrompt();
        navigator.clipboard.writeText(prompt).then(() => {
            setTimeout(() => {
                window.open("https://gemini.google.com/gem/1S5pQu0VtQMKtWJfxbECTlxFkbP5yFsC_?usp=sharing", "_blank");
                setIsCopying(false);
                onClose();
            }, 800);
        });
    };

    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden border border-indigo-100">
                <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-6 text-white relative">
                    <button onClick={onClose} className="absolute top-4 right-4 p-1 hover:bg-white/20 rounded-full transition-colors"><X className="w-5 h-5"/></button>
                    <div className="flex items-center gap-3 mb-2">
                        <div className="p-2 bg-white/20 rounded-lg backdrop-blur-md">
                            <Bot className="w-6 h-6 text-yellow-300" />
                        </div>
                        <h3 className="text-xl font-bold font-burmese">AI Dhamma Tutor</h3>
                    </div>
                    <p className="text-indigo-100 text-sm opacity-90 font-burmese">ဆရာကြီး၏ ပို့ချချက်များနှင့် ချိတ်ဆက်လေ့လာပါ</p>
                </div>
                
                <div className="p-6 space-y-4">
                    <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 font-burmese">မေးခွန်း (Your Question)</label>
                        <textarea 
                            value={userQuestion}
                            onChange={(e) => setUserQuestion(e.target.value)}
                            className="w-full p-4 border border-slate-200 rounded-xl focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 outline-none font-burmese leading-loose resize-none h-32 text-slate-900 bg-white"
                            placeholder="သိလိုသည်များကို ဤနေရာတွင် ရေးပါ..."
                            autoFocus
                        />
                    </div>

                    <div className="bg-blue-50 p-3 rounded-lg border border-blue-100 flex gap-3 items-start">
                        <Check className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                        <div className="text-xs text-blue-800 font-burmese leading-relaxed">
                            <strong>အဆင်သင့်ဖြစ်ပါပြီ။</strong> အောက်ပါခလုတ်ကို နှိပ်လိုက်ပါက သင်ခန်းစာအနှစ်ချုပ်၊ ရည်ရွယ်ချက်များနှင့် သင့်မေးခွန်းကို Copy ကူးယူပေးပါမည်။ ထို့နောက် Gemini တွင် <strong>Paste (Ctrl+V)</strong> လုပ်ပြီး မေးမြန်းနိုင်ပါသည်။
                        </div>
                    </div>

                    <button 
                        onClick={handleCopyAndLaunch}
                        disabled={!userQuestion.trim()}
                        className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-xl font-bold text-base shadow-lg shadow-indigo-500/30 transition-all active:scale-[0.98] flex items-center justify-center gap-2"
                    >
                        {isCopying ? <Loader2 className="w-5 h-5 animate-spin"/> : <ExternalLink className="w-5 h-5" />}
                        {isCopying ? "Preparing Context..." : "Copy Context & Open Gemini"}
                    </button>
                </div>
            </div>
        </div>
    );
};

// --- Refactored Rich Text Editor (Robust) ---
const RichTextEditor = ({ value, onChange, placeholder }: { value: string; onChange: (val: string) => void, placeholder?: string }) => {
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const insertTag = (tag: string) => {
    const textarea = textareaRef.current;
    if (!textarea) return;
    
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const text = textarea.value;
    const before = text.substring(0, start);
    const after = text.substring(end);
    const selection = text.substring(start, end);
    
    let newText = '';
    
    if (tag === 'b') newText = `${before}<strong>${selection}</strong>${after}`;
    else if (tag === 'i') newText = `${before}<em>${selection}</em>${after}`;
    else if (tag === 'ul') newText = `${before}\n<ul>\n  <li>${selection}</li>\n</ul>\n${after}`;
    else if (tag === 'h1') newText = `${before}<h1>${selection}</h1>${after}`;
    else if (tag === 'h2') newText = `${before}<h2>${selection}</h2>${after}`;
    
    // We update the parent state
    onChange(newText);

    // Attempt to restore focus (basic)
    setTimeout(() => {
        textarea.focus();
    }, 0);
  };

  return (
    <div className="flex flex-col h-full bg-white rounded-lg overflow-hidden border border-slate-200">
      <div className="bg-slate-50 border-b border-slate-200 p-2 flex gap-1 shrink-0 justify-center">
        <button type="button" onClick={() => insertTag('b')} className="p-2 hover:bg-slate-200 rounded text-slate-700 font-bold" title="Bold"><Bold className="w-4 h-4" /></button>
        <button type="button" onClick={() => insertTag('i')} className="p-2 hover:bg-slate-200 rounded text-slate-700 italic" title="Italic"><Italic className="w-4 h-4" /></button>
        <div className="w-px h-6 bg-slate-300 mx-2 self-center"></div>
        <button type="button" onClick={() => insertTag('h1')} className="p-2 hover:bg-slate-200 rounded text-slate-700" title="Heading 1"><Heading1 className="w-4 h-4" /></button>
        <button type="button" onClick={() => insertTag('h2')} className="p-2 hover:bg-slate-200 rounded text-slate-700" title="Heading 2"><Heading2 className="w-4 h-4" /></button>
        <div className="w-px h-6 bg-slate-300 mx-2 self-center"></div>
        <button type="button" onClick={() => insertTag('ul')} className="p-2 hover:bg-slate-200 rounded text-slate-700" title="Bullet List"><List className="w-4 h-4" /></button>
      </div>
      <textarea
        ref={textareaRef}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="flex-1 p-8 outline-none font-['Padauk'] text-lg leading-relaxed resize-none bg-white text-slate-900 focus:bg-slate-50/30 transition-colors w-full max-w-3xl mx-auto shadow-sm my-4 rounded-lg border border-slate-100"
        placeholder={placeholder || "Type your content here... HTML tags supported."}
      />
    </div>
  );
};

// --- Focus Answer Editor Modal ---
const FocusAnswerEditor = ({ 
    isOpen, 
    onClose, 
    question, 
    value, 
    onChange 
}: { 
    isOpen: boolean; 
    onClose: () => void; 
    question: string; 
    value: string; 
    onChange: (val: string) => void 
}) => {
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-in fade-in duration-200">
            <div className="bg-slate-100 rounded-2xl shadow-2xl w-full max-w-5xl h-[90vh] flex flex-col overflow-hidden">
                <div className="p-4 bg-white border-b border-slate-200 flex justify-between items-center shrink-0">
                    <div>
                        <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider mb-1 block">Editing Answer for:</span>
                        <h3 className="font-bold text-slate-800 line-clamp-1 font-burmese text-lg">{question}</h3>
                    </div>
                    <div className="flex gap-3">
                        <button onClick={onClose} className="px-4 py-2 text-slate-500 hover:bg-slate-100 rounded-lg text-sm font-bold">Cancel</button>
                        <button onClick={onClose} className="px-6 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-bold shadow-sm">Done</button>
                    </div>
                </div>
                <div className="flex-1 p-0 overflow-hidden bg-slate-50 relative">
                    <RichTextEditor value={value} onChange={onChange} placeholder="Write your refined answer here..." />
                </div>
            </div>
        </div>
    );
};

// --- MAIN COMPONENT ---
export const ChapterView: React.FC<Props> = ({
  chapter,
  isPresentationMode,
  chapterImages,
  customDiagrams,
  customHtml,
  resources,
  quiz,
  onAddImage,
  onRemoveImage,
  onBulkRemoveImage,
  onReorderImages,
  onAddDiagram,
  onRemoveDiagram,
  onReorderDiagrams,
  onSetHtml,
  onRemoveHtml,
  onUpdateResources,
  onSaveQuiz,
  isReadOnly,
  activeTab,
  onTabChange,
  onClearDiagrams,
  showToast,
  onBulkMoveToVisual,
  onExitPresentation,
  onEnterPresentation,
  language,
  isFocusMode,
  onToggleFocusMode
}) => {
  const [isEditingResources, setIsEditingResources] = useState(false);
  const [resourceForm, setResourceForm] = useState({ audio: '', youtube: '', question: '', linkTitle: '', linkUrl: '' });
  const [isEditingHtml, setIsEditingHtml] = useState(false);
  const [htmlInput, setHtmlInput] = useState('');
  const [activeDiagramIndex, setActiveDiagramIndex] = useState(0);
  const [showDefaultContent, setShowDefaultContent] = useState(true);
  const [isProcessingDiagram, setIsProcessingDiagram] = useState(false);
  const filmstripRef = useRef<HTMLDivElement>(null);
  const [isGridView, setIsGridView] = useState(false);
  const [selectedSlides, setSelectedSlides] = useState<number[]>([]);
  const [isConfirmingDelete, setIsConfirmingDelete] = useState(false);
  const quizJsonTextareaRef = useRef<HTMLTextAreaElement>(null);
  const visualInputRef = useRef<HTMLInputElement>(null);
  
  // Drag and Drop State
  const [draggedSlideIndex, setDraggedSlideIndex] = useState<number | null>(null);
  
  // Discussion Questions AI
  const [discussionJsonInput, setDiscussionJsonInput] = useState('');
  const discussionTextareaRef = useRef<HTMLTextAreaElement>(null);

  // Question Management
  const [editingQIndex, setEditingQIndex] = useState<number | null>(null);
  const [editQText, setEditQText] = useState('');

  // Assignment Workspace (Student Mode)
  const [studentAnswers, setStudentAnswers] = useState<Record<number, string>>({});
  const [studentName, setStudentName] = useState('');
  const [activeQuestionIdx, setActiveQuestionIdx] = useState<number | null>(null);
  const [isFocusEditorOpen, setIsFocusEditorOpen] = useState(false);

  // AI Tutor & Quiz
  const [isAIModalOpen, setIsAIModalOpen] = useState(false);
  const [aiQuestion, setAiQuestion] = useState('');
  const [quizJsonInput, setQuizJsonInput] = useState('');
  const [isQuizRunning, setIsQuizRunning] = useState(false);

  // Presentation State
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [slides, setSlides] = useState<string[]>([]);
  const [isLaserPointerActive, setIsLaserPointerActive] = useState(false);
  const presentationRef = useRef<HTMLDivElement>(null);
  const [laserPosition, setLaserPosition] = useState({ x: 0, y: 0 });

  // Mobile Header State
  const [isHeaderExpanded, setIsHeaderExpanded] = useState(false);

  // Typography State
  const [fontSizeLevel, setFontSizeLevel] = useState(1); // 0: sm, 1: base, 2: lg, 3: xl

  useEffect(() => {
    setResourceForm({
        audio: resources?.audio || '',
        youtube: resources?.youtube || '',
        question: '',
        linkTitle: '',
        linkUrl: ''
    });
    setHtmlInput(customHtml || '');
    setActiveDiagramIndex(0);
    if (customHtml) setShowDefaultContent(false);
    setIsGridView(false);
    setSelectedSlides([]);
    setEditingQIndex(null);
    setIsConfirmingDelete(false);
    setIsAIModalOpen(false);
    setAiQuestion('');
    setQuizJsonInput('');
    setDiscussionJsonInput('');
    setIsQuizRunning(false);
    setIsHeaderExpanded(false); 
    setIsEditingHtml(false); // Reset edit mode on chapter change
    
    // Load student answers and name from local storage
    const savedAnswers = localStorage.getItem(`assignment_answers_${chapter.id}`);
    if (savedAnswers) {
        setStudentAnswers(JSON.parse(savedAnswers));
    } else {
        setStudentAnswers({});
    }
    const savedName = localStorage.getItem(`assignment_student_name_${chapter.id}`);
    if (savedName) setStudentName(savedName);

  }, [chapter.id, resources, customHtml]);

  // Save student answers to local storage whenever they change
  useEffect(() => {
      if (Object.keys(studentAnswers).length > 0) {
          localStorage.setItem(`assignment_answers_${chapter.id}`, JSON.stringify(studentAnswers));
      }
  }, [studentAnswers, chapter.id]);

  useEffect(() => {
      localStorage.setItem(`assignment_student_name_${chapter.id}`, studentName);
  }, [studentName, chapter.id]);

  // Slides Setup
  useEffect(() => {
      const newSlides = ['intro', 'summary']; 
      if (customHtml) newSlides.push('notes');
      if (customDiagrams.length > 0) {
          customDiagrams.forEach((_, index) => {
              newSlides.push(`visual-${index}`);
          });
      } else {
          newSlides.push('visual-default');
      }
      newSlides.push('keypoints'); 
      if (chapterImages.length > 0) newSlides.push('gallery');
      if (resources?.audio || resources?.youtube || (resources?.questions && resources.questions.length > 0) || (resources?.links && resources.links.length > 0)) {
          newSlides.push('resources');
      }
      setSlides(newSlides);
      setCurrentSlideIndex(0); 
  }, [chapter.id, customHtml, chapterImages.length, resources, customDiagrams.length]);

  // Keyboard Navigation & Laser Pointer Logic
  useEffect(() => {
      if (!isPresentationMode) return;

      const handleKeyDown = (e: KeyboardEvent) => {
          if (e.key === 'ArrowRight' || e.key === ' ') {
              setCurrentSlideIndex(prev => Math.min(prev + 1, slides.length - 1));
          } else if (e.key === 'ArrowLeft') {
              setCurrentSlideIndex(prev => Math.max(0, prev - 1));
          } else if (e.key.toLowerCase() === 'l') {
              setIsLaserPointerActive(prev => !prev);
          } else if (e.key === 'Escape' && onExitPresentation) {
             onExitPresentation();
          }
      };

      const handleMouseMove = (e: MouseEvent) => {
          if (isLaserPointerActive) {
              setLaserPosition({ x: e.clientX, y: e.clientY });
          }
      };

      window.addEventListener('keydown', handleKeyDown);
      window.addEventListener('mousemove', handleMouseMove);
      return () => {
          window.removeEventListener('keydown', handleKeyDown);
          window.removeEventListener('mousemove', handleMouseMove);
      };
  }, [isPresentationMode, slides.length, isLaserPointerActive, onExitPresentation]);


  // Quiz Handling
  const getPromptText = () => {
      const prompt = `
ROLE: You are Dr. Soe Lwin, a master of Abhidhamma and Insight Meditation.

TASK: Create a "Deep Root Cause Analysis" Quiz (10 Questions).

APP CONTEXT: "Wisdom-Guided Mindful Living (Level 1)"
OBJECTIVE: To help common people apply Buddha's teachings in daily life to reduce suffering.

TOPIC: Chapter ${chapter.id}: ${chapter.titleBurmese} (${chapter.titleEnglish})

METHODOLOGY: "THE FIVE WHYS" & "PATICCASAMUPPADA" (Cause & Effect)
1. Do NOT ask surface-level questions like "What is X?".
2. Instead, ask about the ROOT CAUSE (အကြောင်းရင်းအမှန်) or the CONSEQUENCE (အကျိုးဆက်).
3. Use the "Five Whys" technique: Ask yourself "Why?" 5 times to find the deep Dhamma reason, then frame the question around that deep reason.
   - Bad Example: "What is Dosa?"
   - Good Example: "Why does Dosa arise even when we want to be happy? (Answer involves lack of Yoniso Manasikara or Unwise Attention)"

INSTRUCTIONS:
1. Search your Knowledge Base (the 29 books) for deep insights related to this chapter.
2. Generate **10 Multiple Choice Questions** in **Burmese (Myanmar Language)**.
3. Questions must test *Understanding*, not just *Memory*.
4. Provide the output in this EXACT JSON format (Array of Objects):

[
  {
    "id": 1,
    "question": "Question text in Burmese (Focus on Why/How/Root Cause)",
    "options": ["Option A", "Option B", "Option C", "Option D"],
    "correctAnswer": 0,
    "explanation": "Deep explanation using the Five Whys logic. Explain clearly why the answer is the root cause."
  },
  ... (9 more questions)
]

IMPORTANT: Return ONLY the JSON array. Do not add markdown formatting.
`.trim();
      return prompt;
  };

  const getDiscussionPrompt = () => {
    const prompt = `
ROLE: Dhamma Teacher for International Students in "Wisdom-Guided Mindful Living".
TASK: Generate 5-10 Deep Discussion Questions for students to reflect on.

TOPIC: Chapter ${chapter.id}: ${chapter.titleBurmese} (${chapter.titleEnglish})

GOAL: Help students apply this specific chapter to their daily life to reduce anxiety and gain wisdom.

INSTRUCTIONS:
1. Create open-ended questions that force students to apply the Dhamma to their daily life.
2. Avoid "Yes/No" questions. Use "How", "Why", "In what situation...", "Reflect on...".
3. Language: Burmese (Myanmar Language).
4. Output Format: A simple JSON Array of Strings.

Example Output:
[
  "နေ့စဉ်ဘဝတွင် လောဘဖြစ်ပေါ်လာသောအခါ မည်သို့သတိထားမိသနည်း။",
  "သင့်စိတ်ကို အိမ်ရှင်နှင့် ဧည့်သည် ခွဲခြားကြည့်သောအခါ မည်သို့ခံစားရသနည်း။"
]

IMPORTANT: Return ONLY the JSON array of strings. No markdown.
`.trim();
    return prompt;
  };

  const handleCopyPromptOnly = () => {
      navigator.clipboard.writeText(getPromptText());
      showToast("Prompt Copied to Clipboard!");
  };

  const handleCopyAndOpenGemini = () => {
    navigator.clipboard.writeText(getPromptText());
    showToast("Prompt Copied! Opening Gemini...");
    
    // Automatically open Gemini in a new tab
    setTimeout(() => {
        window.open("https://gemini.google.com/gem/1S5pQu0VtQMKtWJfxbECTlxFkbP5yFsC_?usp=sharing", "_blank");
    }, 1000);
  };

  const handleCopyDiscussionPromptOnly = () => {
    navigator.clipboard.writeText(getDiscussionPrompt());
    showToast("Prompt Copied! (Ready for Gemini)");
  };

  const handleOpenGemini = () => {
      window.open("https://gemini.google.com/gem/1S5pQu0VtQMKtWJfxbECTlxFkbP5yFsC_?usp=sharing", "_blank");
  };

  const handlePasteFromClipboard = async () => {
      try {
          const text = await navigator.clipboard.readText();
          if (text) {
              setQuizJsonInput(text);
              showToast("Pasted from Clipboard!");
          } else {
              showToast("Clipboard is empty", "info");
          }
      } catch (err) {
          console.error("Failed to read clipboard:", err);
          showToast("Auto-paste blocked. Click box & Ctrl+V", "info");
          // Fallback: Focus the textarea so user can easily Ctrl+V
          if (quizJsonTextareaRef.current) {
              quizJsonTextareaRef.current.focus();
          }
      }
  };

  const handlePasteDiscussionJson = async () => {
      try {
          const text = await navigator.clipboard.readText();
          if (!text) {
              showToast("Clipboard is empty", "info");
              return;
          }
          
          try {
              const json = JSON.parse(text);
              if (Array.isArray(json) && json.every(item => typeof item === 'string')) {
                  // Append to existing questions
                  const currentQuestions = resources?.questions || [];
                  const newQuestions = [...currentQuestions, ...json];
                  onUpdateResources(resources?.audio, resources?.youtube, newQuestions, resources?.links);
                  showToast(`Added ${json.length} Discussion Questions!`);
                  setDiscussionJsonInput('');
              } else {
                  showToast("Invalid JSON. Must be Array of Strings.", "error");
              }
          } catch (e) {
              showToast("Invalid JSON Format", "error");
          }
      } catch (err) {
          showToast("Permission denied. Paste manually.", "error");
           if (discussionTextareaRef.current) {
              discussionTextareaRef.current.focus();
          }
      }
  };

  const handleQuizJsonUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
          const text = ev.target?.result as string;
          try {
              const json = JSON.parse(text);
              if (Array.isArray(json)) {
                  onSaveQuiz({ chapterId: chapter.id, questions: json });
                  showToast("Quiz Loaded Successfully!");
              } else {
                  showToast("Invalid JSON Format", "error");
              }
          } catch (err) {
              showToast("Failed to parse JSON", "error");
          }
      };
      reader.readAsText(file);
      if (e.target) e.target.value = '';
  };

  const handlePasteQuizJson = () => {
      try {
          const json = JSON.parse(quizJsonInput);
          if (Array.isArray(json)) {
              onSaveQuiz({ chapterId: chapter.id, questions: json });
              showToast("Quiz Saved Successfully!");
              setQuizJsonInput('');
          } else {
              showToast("Invalid JSON Format (Must be Array)", "error");
          }
      } catch (err) {
          showToast("Invalid JSON Syntax", "error");
      }
  };

  const handleExportAssignment = () => {
      if (!studentName.trim()) {
          showToast("Please enter your name first.", 'error');
          return;
      }
      const questions = resources?.questions || [];
      if (questions.length === 0) {
          showToast("No questions to export", 'error');
          return;
      }

      const assignmentHtml = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assignment - ${chapter.titleEnglish}</title>
    <link href="https://fonts.googleapis.com/css2?family=Padauk:wght@400;700&family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', 'Padauk', sans-serif; max-width: 800px; margin: 40px auto; padding: 20px; line-height: 1.6; color: #333; background-color: #f9fafb; }
        .container { background: white; padding: 40px; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); border: 1px solid #e5e7eb; }
        h1 { color: #4f46e5; margin-bottom: 5px; font-size: 24px; }
        h2 { font-size: 16px; color: #6b7280; font-weight: 500; margin-bottom: 30px; border-bottom: 1px solid #e5e7eb; padding-bottom: 20px; }
        .student-info { margin-bottom: 30px; padding: 15px; background: #f0f9ff; border-radius: 8px; border-left: 4px solid #0ea5e9; }
        .q-block { margin-bottom: 30px; page-break-inside: avoid; }
        .question { font-weight: bold; color: #111827; margin-bottom: 10px; background: #eff6ff; padding: 15px; border-radius: 8px; border-left: 4px solid #4f46e5; }
        .answer { margin-left: 0; white-space: pre-wrap; color: #374151; background: #f9fafb; padding: 15px; border-radius: 8px; border: 1px solid #e5e7eb; min-height: 60px; font-family: 'Padauk', sans-serif; line-height: 1.8; font-size: 16px; }
        .footer { margin-top: 50px; font-size: 12px; color: #9ca3af; text-align: center; border-top: 1px solid #e5e7eb; padding-top: 20px; }
        @media print { body { background: none; margin: 0; } .container { box-shadow: none; border: none; padding: 0; } }
    </style>
</head>
<body>
    <div class="container">
        <h1>Assignment: ${chapter.titleBurmese}</h1>
        <h2>${chapter.titleEnglish}</h2>
        
        <div class="student-info">
            <strong>Student Name:</strong> ${studentName}<br>
            <strong>Date:</strong> ${new Date().toLocaleDateString()}
        </div>

        ${questions.map((q, idx) => `
            <div class="q-block">
                <div class="question">Q${idx + 1}: ${q}</div>
                <div class="answer">${studentAnswers[idx] || '(No answer provided)'}</div>
            </div>
        `).join('')}

        <div class="footer">
            Generated by Wisdom-Guided Mindful Living App
        </div>
    </div>
</body>
</html>
      `;

      const blob = new Blob([assignmentHtml], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `Assignment_${studentName.replace(/\s+/g,'_')}_Ch${chapter.id}.html`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      showToast("Assignment exported successfully!");
  };

  // --- Visual Aid Upload Handler (PDF & Images) ---
  const handleVisualUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const files = e.target.files;
      if (!files || files.length === 0) return;

      setIsProcessingDiagram(true);
      try {
        // Explicitly cast to File[] to avoid 'unknown' type issues in iteration
        const fileArray = Array.from(files) as File[];
        let count = 0;

        for (const file of fileArray) {
            if (file.type === 'application/pdf') {
                showToast("Converting PDF pages to slides...", "info");
                // Convert PDF pages to individual images
                const pdfImages = await convertPdfToImages(file);
                onAddDiagram(pdfImages);
                count += pdfImages.length;
            } else {
                // Process standard image
                const img = await processImage(file);
                onAddDiagram(img);
                count++;
            }
        }
        showToast(`Added ${count} slides successfully!`);
      } catch (err) {
        console.error("Visual Upload Error:", err);
        showToast("Failed to process file(s). Try another format.", "error");
      } finally {
        setIsProcessingDiagram(false);
        if (visualInputRef.current) visualInputRef.current.value = '';
      }
  };

  // --- Handlers Re-implementation for UI ---
  const handleSaveResources = () => {
    onUpdateResources(resourceForm.audio, resourceForm.youtube, resources?.questions || [], resources?.links || []);
    setIsEditingResources(false);
    showToast("Resources updated");
  };
  const handleAddLink = () => {
      if (!resourceForm.linkTitle || !resourceForm.linkUrl) { showToast("Enter title and URL", 'error'); return; }
      const newLink = { title: resourceForm.linkTitle, url: resourceForm.linkUrl };
      onUpdateResources(resources?.audio, resources?.youtube, resources?.questions, [...(resources?.links || []), newLink]);
      setResourceForm(prev => ({ ...prev, linkTitle: '', linkUrl: '' }));
      showToast("Link added");
  };
  const handleRemoveLink = (idx: number) => {
      if(window.confirm("Remove link?")) {
          onUpdateResources(resources?.audio, resources?.youtube, resources?.questions, (resources?.links || []).filter((_, i) => i !== idx));
          showToast("Link removed", 'info');
      }
  };
  const handleAddQuestion = () => {
    if (!resourceForm.question.trim()) return;
    onUpdateResources(resources?.audio, resources?.youtube, [...(resources?.questions || []), resourceForm.question], resources?.links);
    setResourceForm(prev => ({ ...prev, question: '' }));
    showToast("Question added");
  };
  const handleDeleteQuestion = (idx: number) => {
    if (window.confirm("Remove question?")) {
        onUpdateResources(resources?.audio, resources?.youtube, (resources?.questions || []).filter((_, i) => i !== idx), resources?.links);
        showToast("Question removed", 'info');
    }
  };
  const startEditQuestion = (idx: number, currentText: string) => { setEditingQIndex(idx); setEditQText(currentText); };
  const saveEditQuestion = () => {
    if (editingQIndex === null) return;
    const updated = [...(resources?.questions || [])]; updated[editingQIndex] = editQText;
    onUpdateResources(resources?.audio, resources?.youtube, updated, resources?.links);
    setEditingQIndex(null); setEditQText(''); showToast("Updated");
  };
  const handleAskAI = (question?: string) => { setAiQuestion(question || ''); setIsAIModalOpen(true); };

  // Helper Functions for Visual Aid Management
  const toggleSelection = (idx: number) => {
      if (selectedSlides.includes(idx)) setSelectedSlides(prev => prev.filter(i => i !== idx));
      else setSelectedSlides(prev => [...prev, idx]);
  };
  const handleBulkDelete = () => {
      if (selectedSlides.length === 0) return;
      if (isConfirmingDelete) {
          const newDiagrams = customDiagrams.filter((_, i) => !selectedSlides.includes(i));
          if (onReorderDiagrams) onReorderDiagrams(newDiagrams);
          setSelectedSlides([]); setIsConfirmingDelete(false); showToast(`Deleted ${selectedSlides.length} slides`, 'info');
      } else { setIsConfirmingDelete(true); setTimeout(() => setIsConfirmingDelete(false), 3000); }
  };
  const handleBulkMoveToGallery = () => {
      if (selectedSlides.length === 0) return;
      const imagesToMove = selectedSlides.map(i => customDiagrams[i]);
      onAddImage(imagesToMove);
      const newDiagrams = customDiagrams.filter((_, i) => !selectedSlides.includes(i));
      if (onReorderDiagrams) onReorderDiagrams(newDiagrams);
      setSelectedSlides([]); showToast(`Moved ${imagesToMove.length} images to Gallery`);
  };

  // --- DRAG AND DROP HANDLERS ---
  const handleDragStart = (e: React.DragEvent, index: number) => {
      setDraggedSlideIndex(index);
      e.dataTransfer.effectAllowed = "move";
  };

  const handleDragOver = (e: React.DragEvent, index: number) => {
      e.preventDefault(); 
      e.dataTransfer.dropEffect = "move";
  };

  const handleDrop = (e: React.DragEvent, dropIndex: number) => {
      e.preventDefault();
      if (draggedSlideIndex === null || draggedSlideIndex === dropIndex) return;

      if (onReorderDiagrams) {
          const newDiagrams = [...customDiagrams];
          const [movedItem] = newDiagrams.splice(draggedSlideIndex, 1);
          newDiagrams.splice(dropIndex, 0, movedItem);
          onReorderDiagrams(newDiagrams);
          showToast("Slide reordered");
      }
      setDraggedSlideIndex(null);
  };

  // --- TAB CONFIG ---
  const TABS = [
      { id: 'content', icon: FileText, label: 'Notes', burmese: 'သင်ခန်းစာ' },
      { id: 'visual', icon: BookOpen, label: 'Visual Aid', burmese: 'ပုံဥပမာ' },
      { id: 'gallery', icon: ImageIcon, label: 'Gallery', burmese: 'ပုံများ' },
      { id: 'quiz', icon: GraduationCap, label: 'Quiz', burmese: 'လေ့ကျင့်ခန်း' },
      { id: 'resources', icon: PlayCircle, label: 'Resources', burmese: 'အထောက်အကူ' },
  ];

  // --- RENDER HELPERS ---

  const renderVisualPanel = () => (
      <div className="h-full flex flex-col gap-4 sm:gap-6">
        {!isReadOnly && (
            <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-2 sm:p-3 rounded-xl border border-slate-200 shadow-sm shrink-0">
                <div className="flex gap-2">
                        <button 
                        onClick={() => setIsGridView(!isGridView)} 
                        className={`p-2 rounded-lg text-xs sm:text-sm font-medium flex items-center gap-2 transition-colors ${isGridView ? 'bg-indigo-600 text-white shadow-sm' : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-200'}`}
                        >
                        <LayoutGrid className="w-4 h-4" /> 
                        <span className="hidden sm:inline">{isGridView ? 'Close Grid' : 'Manage Slides'}</span>
                        </button>

                        {isGridView && customDiagrams.length > 0 && (
                        <button 
                            onClick={() => selectedSlides.length === customDiagrams.length ? setSelectedSlides([]) : setSelectedSlides(customDiagrams.map((_, i) => i))} 
                            className="flex items-center gap-2 px-3 py-1.5 text-xs font-bold text-slate-600 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors"
                        >
                            {selectedSlides.length === customDiagrams.length ? <CheckSquare className="w-4 h-4 text-indigo-600" /> : <Square className="w-4 h-4" />}
                            <span className="hidden sm:inline">Select All</span>
                        </button>
                        )}
                </div>
                <div className="flex items-center gap-2">
                    {isGridView && selectedSlides.length > 0 && (
                        <>
                            <button onClick={handleBulkMoveToGallery} className="flex items-center gap-2 px-3 py-1.5 text-xs font-bold text-indigo-600 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 rounded-lg transition-colors"><ImageIcon className="w-4 h-4" /> <span className="hidden sm:inline">To Gallery</span></button>
                            <button onClick={handleBulkDelete} className={`flex items-center gap-2 px-3 py-1.5 text-xs font-bold rounded-lg transition-colors border ${isConfirmingDelete ? 'text-white bg-red-600 animate-pulse' : 'text-red-600 bg-red-50 border-red-200'}`}><Trash2 className="w-4 h-4" /> {isConfirmingDelete ? '?' : 'Del'}</button>
                        </>
                    )}
                    <div className="h-6 w-px bg-slate-200 mx-1 hidden sm:block"></div>
                    <label className={`cursor-pointer flex items-center gap-2 text-xs sm:text-sm text-white bg-indigo-600 hover:bg-indigo-700 px-4 py-2 rounded-lg transition-all font-bold shadow-md hover:shadow-lg active:scale-95 ${isProcessingDiagram ? 'opacity-75 cursor-wait' : ''}`}>
                        {isProcessingDiagram ? <Loader2 className="w-4 h-4 animate-spin"/> : <Plus className="w-4 h-4" />}
                        <span>{isProcessingDiagram ? 'Processing...' : 'Add Slide / PDF'}</span>
                        <input ref={visualInputRef} type="file" accept="image/*,application/pdf" multiple onChange={handleVisualUpload} className="hidden" disabled={isProcessingDiagram} />
                    </label>
                </div>
            </div>
        )}

        <div className="flex-1 min-h-[400px] flex flex-col relative group">
            {isGridView && customDiagrams.length > 0 ? (
                <div className="flex flex-col h-full bg-slate-100/50 rounded-xl border border-slate-200 overflow-hidden">
                        {/* DRAG TIP BANNER */}
                        {!isReadOnly && (
                            <div className="bg-indigo-50 px-4 py-2 text-xs text-indigo-700 flex items-center justify-center gap-2 border-b border-indigo-100 font-bold">
                                <GripHorizontal className="w-4 h-4" />
                                <span>Drag and drop slides to reorder them for presentation.</span>
                            </div>
                        )}
                        <div className="p-4 overflow-y-auto custom-scrollbar flex-1 min-h-0">
                        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                            {customDiagrams.map((img, idx) => (
                                <div 
                                    key={idx} 
                                    draggable={!isReadOnly}
                                    onDragStart={(e) => handleDragStart(e, idx)}
                                    onDragOver={(e) => handleDragOver(e, idx)}
                                    onDrop={(e) => handleDrop(e, idx)}
                                    className={`relative group bg-white rounded-xl shadow-sm border transition-all duration-200
                                        ${selectedSlides.includes(idx) ? 'ring-2 ring-indigo-500 border-indigo-500' : 'border-slate-200'}
                                        ${draggedSlideIndex === idx ? 'opacity-50 scale-95 border-dashed border-indigo-400' : ''}
                                        ${!isReadOnly ? 'cursor-grab active:cursor-grabbing hover:shadow-md' : ''}
                                    `}
                                >
                                    <div className="aspect-video w-full overflow-hidden rounded-t-xl bg-slate-50 relative" onClick={() => { if (!isReadOnly) toggleSelection(idx); else { setActiveDiagramIndex(idx); setIsGridView(false); }}}>
                                        <img src={img} className="w-full h-full object-cover pointer-events-none" alt={`Slide ${idx + 1}`} loading="lazy" />
                                        
                                        {!isReadOnly && (
                                            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/5 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100">
                                                <GripHorizontal className="w-8 h-8 text-white drop-shadow-md" />
                                            </div>
                                        )}
                                    </div>
                                    
                                    <div className="absolute bottom-2 right-2 bg-black/50 text-white text-[10px] px-2 py-0.5 rounded-full backdrop-blur-sm pointer-events-none">
                                        Slide {idx + 1}
                                    </div>

                                    {!isReadOnly && (
                                        <div className="absolute top-2 left-2 z-10" onClick={(e) => { e.stopPropagation(); toggleSelection(idx); }}>
                                            <div className={`w-5 h-5 rounded border bg-white flex items-center justify-center cursor-pointer ${selectedSlides.includes(idx) ? 'bg-indigo-500 border-indigo-500 text-white' : 'border-slate-300'}`}><Check className="w-3.5 h-3.5" /></div>
                                        </div>
                                    )}
                                </div>
                            ))}
                        </div>
                        </div>
                </div>
            ) : (
                <div className="flex flex-col h-full">
                    <div className={`flex-1 min-h-0 relative flex items-center justify-center bg-slate-100/50 rounded-xl border border-slate-200 overflow-hidden group`}>
                        {customDiagrams.length > 0 ? (
                            customDiagrams[activeDiagramIndex].startsWith('data:application/pdf') ? (
                                <div className="w-full h-full bg-slate-800 rounded-xl overflow-hidden shadow-2xl border border-slate-700">
                                   <PDFViewer pdfUrl={customDiagrams[activeDiagramIndex]} isPresentationMode={false} />
                                </div>
                            ) : (
                                <img src={customDiagrams[activeDiagramIndex]} alt="Diagram" className="max-h-full max-w-full object-contain p-2 sm:p-4"/>
                            )
                        ) : (
                            chapter.id === 1 ? <RootsTree /> : chapter.id === 2 ? <KammaVsNana /> : chapter.id === 3 ? <SilaSamadhiPanna /> : chapter.id === 4 ? <MindProcess /> : chapter.id === 5 ? <VedanaCycle /> : chapter.id === 6 ? <SannaPerception /> : chapter.id === 7 ? <PresentMoment /> : chapter.id === 8 ? <HostGuest /> : <SatiVsUpadana />
                        )}
                        {customDiagrams.length > 1 && (
                            <>
                                <button onClick={() => setActiveDiagramIndex(prev => prev === 0 ? customDiagrams.length - 1 : prev - 1)} className="absolute left-2 sm:left-4 top-1/2 -translate-y-1/2 p-2 bg-black/10 hover:bg-black/20 rounded-full text-slate-600"><ChevronLeft className="w-6 h-6" /></button>
                                <button onClick={() => setActiveDiagramIndex(prev => (prev + 1) % customDiagrams.length)} className="absolute right-2 sm:right-4 top-1/2 -translate-y-1/2 p-2 bg-black/10 hover:bg-black/20 rounded-full text-slate-600"><ChevronRight className="w-6 h-6" /></button>
                            </>
                        )}
                    </div>
                    {customDiagrams.length > 1 && (
                        <div className="mt-4 h-20 sm:h-24 w-full overflow-x-auto custom-scrollbar bg-white border border-slate-200 rounded-lg p-2 flex gap-2 items-center shrink-0" ref={filmstripRef as any}>
                            {customDiagrams.map((img, idx) => (
                                <button key={idx} onClick={() => setActiveDiagramIndex(idx)} className={`h-full aspect-video rounded border-2 overflow-hidden shrink-0 transition-all ${idx === activeDiagramIndex ? 'border-indigo-500 opacity-100 ring-2 ring-indigo-100' : 'border-transparent opacity-60 hover:opacity-100'}`}>
                                    <img src={img} className="w-full h-full object-cover" alt={`Slide ${idx + 1}`} loading="lazy" />
                                </button>
                            ))}
                        </div>
                    )}
                </div>
            )}
        </div>
      </div>
  );

  const renderNotesPanel = () => {
    // EDITOR MODE
    if (isEditingHtml && !isReadOnly) {
        return (
            <div className="h-full flex flex-col bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
                {/* Editor Header */}
                <div className="flex items-center justify-between p-4 border-b border-slate-100 bg-slate-50 shrink-0">
                    <h3 className="font-bold text-slate-700 flex items-center gap-2">
                        <Edit3 className="w-4 h-4 text-indigo-600"/> Edit Lecture Notes
                    </h3>
                    <div className="flex gap-2">
                        <button onClick={() => setIsEditingHtml(false)} className="px-4 py-2 text-slate-600 text-sm font-medium hover:bg-white rounded-lg transition-colors">Cancel</button>
                        <button onClick={() => { onSetHtml(htmlInput); setIsEditingHtml(false); }} className="px-6 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-bold rounded-lg shadow-sm transition-all active:scale-95">Save Changes</button>
                    </div>
                </div>
                {/* Editor Body */}
                <div className="flex-1 p-0 overflow-hidden">
                    <RichTextEditor value={htmlInput} onChange={setHtmlInput} />
                </div>
            </div>
        );
    }

    // READER MODE
    return (
        <div className={`mx-auto bg-white p-4 sm:p-8 rounded-xl shadow-sm min-h-full transition-all duration-300 ${isFocusMode ? 'max-w-6xl shadow-none border-0' : 'max-w-4xl'}`}>
        
        <div className="flex flex-col sm:flex-row justify-between items-center mb-6 sm:mb-8 gap-4 border-b border-slate-100 pb-4">
            {/* Summary Toggle */}
            <div className="flex items-center gap-4 w-full sm:w-auto justify-between sm:justify-start">
                <div className="bg-slate-100 p-1 rounded-lg flex w-full sm:w-auto">
                    <button onClick={() => setShowDefaultContent(true)} className={`flex-1 sm:flex-none px-4 py-1.5 text-xs font-bold rounded-md transition-all ${showDefaultContent ? 'bg-white shadow text-indigo-600' : 'text-slate-500'}`}>Summary</button>
                    <button onClick={() => setShowDefaultContent(false)} className={`flex-1 sm:flex-none px-4 py-1.5 text-xs font-bold rounded-md transition-all ${!showDefaultContent ? 'bg-white shadow text-indigo-600' : 'text-slate-500'}`}>Lecture Notes</button>
                </div>

                {!isReadOnly && !showDefaultContent && (
                    <button 
                        onClick={() => { setIsEditingHtml(true); setHtmlInput(customHtml || ''); }} 
                        className="flex items-center gap-2 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-600 rounded-lg text-xs font-bold transition-colors border border-indigo-100"
                    >
                        <Edit3 className="w-3.5 h-3.5" /> Edit
                    </button>
                )}
            </div>
            
            {/* Font Size Controls - Desktop Only */}
            <div className="hidden sm:flex items-center gap-2 bg-slate-50 p-1 rounded-lg border border-slate-200">
                <Type className="w-4 h-4 text-slate-400 ml-1" />
                <button onClick={() => setFontSizeLevel(Math.max(0, fontSizeLevel - 1))} className="p-1 hover:bg-white rounded text-slate-600 disabled:opacity-30" disabled={fontSizeLevel === 0}><Minus className="w-3 h-3" /></button>
                <span className="text-xs font-bold text-slate-600 w-4 text-center">{fontSizeLevel === 0 ? 'S' : fontSizeLevel === 1 ? 'M' : fontSizeLevel === 2 ? 'L' : 'XL'}</span>
                <button onClick={() => setFontSizeLevel(Math.min(3, fontSizeLevel + 1))} className="p-1 hover:bg-white rounded text-slate-600 disabled:opacity-30" disabled={fontSizeLevel === 3}><Plus className="w-3 h-3" /></button>
            </div>
        </div>

        {showDefaultContent ? (
            <div className={`prose prose-slate max-w-none font-burmese whitespace-pre-wrap text-slate-700 ${fontSizeLevel === 0 ? 'prose-sm leading-loose' : fontSizeLevel === 1 ? 'prose-base leading-[2.6]' : fontSizeLevel === 2 ? 'prose-lg leading-[3]' : 'prose-xl leading-[3.5]'}`}>{chapter.content}</div>
        ) : (
            <div className={`prose prose-slate max-w-none html-content-container text-left ${fontSizeLevel === 0 ? 'prose-sm' : fontSizeLevel === 1 ? 'prose-base' : fontSizeLevel === 2 ? 'prose-lg' : 'prose-xl'}`} dangerouslySetInnerHTML={{ __html: customHtml || '<p class="text-center text-slate-400">No notes yet.</p>' }} />
        )}
        </div>
    );
  };

  // --- MAIN RENDER (With Quiz check) ---
  if (isQuizRunning && quiz) {
      return (
        <Suspense fallback={<TabLoader />}>
            <QuizRunner 
                quiz={quiz} 
                onExit={() => setIsQuizRunning(false)} 
                chapterTitle={language === 'my' ? chapter.titleBurmese : chapter.titleEnglish}
            />
        </Suspense>
      );
  }

  // --- PRESENTATION MODE RENDER ENGINE (unchanged) ---
  if (isPresentationMode) {
      // ... (Same Presentation Logic)
      const currentSlide = slides[currentSlideIndex];
      const renderSlideContent = () => {
          if (currentSlide === 'intro') {
              return (
                  <div className="flex flex-col items-center justify-center h-full text-center p-20 animate-in zoom-in-95 duration-500">
                      <h1 className="text-6xl md:text-8xl font-bold font-burmese text-indigo-400 mb-8 leading-tight">{language === 'my' ? chapter.titleBurmese : chapter.titleEnglish}</h1>
                      <h2 className="text-3xl md:text-5xl text-slate-400 font-serif">{language === 'my' ? chapter.titleEnglish : chapter.titleBurmese}</h2>
                      <div className="mt-12 w-32 h-2 bg-indigo-600 rounded-full"></div>
                  </div>
              );
          } else if (currentSlide === 'summary') {
              return (
                  <div className="flex flex-col items-center justify-center h-full p-20 animate-in fade-in slide-in-from-right-10 duration-500">
                       <h3 className="text-3xl text-indigo-400 font-bold mb-12 uppercase tracking-widest">Summary</h3>
                       <p className="text-4xl md:text-6xl font-burmese leading-[2.2] text-white text-center max-w-6xl">
                           {chapter.summary}
                       </p>
                  </div>
              );
          } else if (currentSlide === 'keypoints') {
              return (
                  <div className="flex flex-col justify-center h-full p-20 animate-in fade-in slide-in-from-bottom-10 duration-500">
                      <h3 className="text-3xl text-indigo-400 font-bold mb-12 uppercase tracking-widest text-center">Key Concepts</h3>
                      <div className="grid gap-10 max-w-6xl mx-auto w-full">
                          {chapter.keyPoints.map((kp, idx) => (
                              <div key={idx} className="bg-slate-800/50 p-8 rounded-2xl border border-slate-700 flex items-start gap-6">
                                  <div className="w-12 h-12 bg-indigo-600 rounded-full flex items-center justify-center text-white font-bold text-xl shrink-0 mt-2">{idx+1}</div>
                                  <div>
                                      <h4 className="text-3xl font-bold text-indigo-200 font-burmese mb-2">{kp.concept}</h4>
                                      <p className="text-2xl text-slate-300 font-burmese leading-relaxed">{kp.definition}</p>
                                  </div>
                              </div>
                          ))}
                      </div>
                  </div>
              );
          } else if (currentSlide === 'notes') {
              return (
                  <div className="h-full p-20 overflow-y-auto custom-scrollbar animate-in fade-in duration-500 select-none">
                      <div className="max-w-6xl mx-auto prose prose-invert prose-2xl">
                          <div dangerouslySetInnerHTML={{ __html: customHtml || '' }} className="font-burmese leading-[2.4]" />
                      </div>
                  </div>
              );
          } else if (currentSlide.startsWith('visual-')) {
              const indexStr = currentSlide.split('-')[1];
              if (indexStr === 'default') {
                   return (
                       <div className="h-full p-10 flex flex-col items-center justify-center animate-in zoom-in-95 duration-500 select-none">
                           <div className="w-full h-full max-w-7xl max-h-[85vh] bg-white rounded-xl overflow-hidden flex items-center justify-center">
                                {chapter.id === 1 ? <RootsTree /> : chapter.id === 2 ? <KammaVsNana /> : chapter.id === 3 ? <SilaSamadhiPanna /> : chapter.id === 4 ? <MindProcess /> : chapter.id === 5 ? <VedanaCycle /> : chapter.id === 6 ? <SannaPerception /> : chapter.id === 7 ? <PresentMoment /> : chapter.id === 8 ? <HostGuest /> : <SatiVsUpadana />}
                           </div>
                           <h3 className="mt-8 text-3xl font-bold text-slate-400 font-burmese">Visual Aid</h3>
                       </div>
                   );
              } else {
                  const idx = parseInt(indexStr);
                  const img = customDiagrams[idx];
                  if (img.startsWith('data:application/pdf')) {
                       return (
                           <div className="h-full p-4 flex flex-col items-center justify-center animate-in fade-in duration-500">
                               <div className="w-full h-full bg-slate-800 rounded-xl overflow-hidden shadow-2xl border border-slate-700">
                                   <PDFViewer pdfUrl={img} isPresentationMode={true} />
                               </div>
                           </div>
                       );
                  }
                  return (
                      <div className="h-full p-10 flex flex-col items-center justify-center animate-in zoom-in-95 duration-500 select-none">
                          <img src={img} alt="Diagram" className="max-w-full max-h-[85vh] object-contain rounded-lg shadow-2xl bg-white" />
                      </div>
                  );
              }
          } else if (currentSlide === 'gallery') {
               return (
                   <div className="h-full p-10 flex flex-col items-center justify-center animate-in fade-in duration-500 select-none">
                        <h3 className="text-3xl text-indigo-400 font-bold mb-8 uppercase tracking-widest">Gallery Preview</h3>
                        <div className="grid grid-cols-4 gap-6 max-w-7xl">
                            {chapterImages.slice(0, 8).map((img, i) => (
                                <img key={i} src={img} className="rounded-lg aspect-video object-cover border-2 border-slate-700" />
                            ))}
                        </div>
                        <p className="mt-8 text-2xl text-slate-500">Total {chapterImages.length} images available</p>
                   </div>
               );
          } else if (currentSlide === 'resources') {
               return (
                   <div className="h-full flex flex-col items-center justify-center p-20 text-center animate-in fade-in duration-500">
                       <h3 className="text-4xl font-bold text-white mb-8">Additional Resources</h3>
                       <div className="grid gap-6 w-full max-w-4xl text-left">
                           {resources?.audio && <div className="bg-slate-800 p-6 rounded-xl border border-slate-700 flex items-center gap-4"><Music className="w-8 h-8 text-indigo-400" /><span className="text-2xl text-slate-200">Audio Lecture Available</span></div>}
                           {resources?.youtube && <div className="bg-slate-800 p-6 rounded-xl border border-slate-700 flex items-center gap-4"><Youtube className="w-8 h-8 text-red-500" /><span className="text-2xl text-slate-200">Video Lesson Available</span></div>}
                           {(resources?.questions || []).length > 0 && <div className="bg-slate-800 p-6 rounded-xl border border-slate-700 flex items-center gap-4"><HelpCircle className="w-8 h-8 text-yellow-500" /><span className="text-2xl text-slate-200">{resources?.questions?.length} Discussion Questions</span></div>}
                       </div>
                   </div>
               );
          }
          return null;
      };

      return (
          <div 
            ref={presentationRef} 
            className={`fixed inset-0 z-[200] bg-slate-950 text-slate-100 flex flex-col overflow-hidden ${isLaserPointerActive ? 'cursor-none select-none' : ''}`}
          >
              {isLaserPointerActive && (
                  <div 
                    className="fixed pointer-events-none z-[300] transition-transform duration-75 ease-out"
                    style={{ 
                        left: laserPosition.x, 
                        top: laserPosition.y,
                        transform: 'translate(-50%, -50%)'
                    }}
                  >
                      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 bg-yellow-300 rounded-full shadow-[0_0_10px_rgba(253,224,71,1)]"></div>
                      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 bg-yellow-400/20 rounded-full blur-xl border-2 border-yellow-400/30"></div>
                  </div>
              )}
              <div className="flex-1 w-full h-full relative">
                  {renderSlideContent()}
              </div>
              <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex items-center gap-6 p-4 bg-black/50 backdrop-blur-md rounded-full border border-white/10 opacity-0 hover:opacity-100 transition-opacity duration-300">
                  <button onClick={() => setCurrentSlideIndex(Math.max(0, currentSlideIndex - 1))} className="p-3 bg-white/10 hover:bg-white/20 rounded-full transition-colors"><ChevronLeft className="w-6 h-6" /></button>
                  <span className="text-lg font-bold font-mono">{currentSlideIndex + 1} / {slides.length}</span>
                  <button onClick={() => setCurrentSlideIndex(Math.min(slides.length - 1, currentSlideIndex + 1))} className="p-3 bg-white/10 hover:bg-white/20 rounded-full transition-colors"><ChevronRight className="w-6 h-6" /></button>
                  <div className="w-px h-6 bg-white/20 mx-2"></div>
                  <button onClick={() => setIsLaserPointerActive(!isLaserPointerActive)} className={`p-3 rounded-full transition-colors ${isLaserPointerActive ? 'bg-yellow-500 text-black' : 'bg-white/10 hover:bg-white/20'}`} title="Toggle Spotlight (L)"><MousePointer2 className="w-6 h-6" /></button>
                  <div className="w-px h-6 bg-white/20 mx-2"></div>
                  <button onClick={onExitPresentation} className="p-3 bg-white/10 hover:bg-red-600/80 rounded-full transition-colors" title="Exit Presentation (Esc)">
                    <X className="w-6 h-6" />
                  </button>
              </div>
          </div>
      );
  }

  // --- JSX RENDER (NORMAL MODE) ---
  return (
    <div className="h-full flex flex-col overflow-hidden bg-slate-50 relative">
      <AITutorModal isOpen={isAIModalOpen} onClose={() => setIsAIModalOpen(false)} chapter={chapter} customHtml={customHtml} prefilledQuestion={aiQuestion}/>
      
      <FocusAnswerEditor 
        isOpen={isFocusEditorOpen} 
        onClose={() => setIsFocusEditorOpen(false)} 
        question={activeQuestionIdx !== null ? (resources?.questions || [])[activeQuestionIdx] : ''}
        value={activeQuestionIdx !== null ? studentAnswers[activeQuestionIdx] || '' : ''}
        onChange={(val) => activeQuestionIdx !== null && setStudentAnswers(prev => ({ ...prev, [activeQuestionIdx]: val }))}
      />

      {!isPresentationMode && (
          <>
            <button 
                onClick={() => handleAskAI()} 
                className="fixed bottom-6 right-4 z-[60] p-3 md:bottom-10 md:right-10 md:p-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-full shadow-[0_4px_20px_rgba(79,70,229,0.5)] hover:shadow-[0_4px_25px_rgba(79,70,229,0.7)] hover:scale-105 transition-all border border-indigo-400 group flex items-center gap-0 overflow-hidden hover:pr-4" 
                title="Ask AI Tutor"
            >
                <Bot className="w-5 h-5 md:w-6 md:h-6 animate-pulse" />
                <span className="w-0 overflow-hidden group-hover:w-auto group-hover:ml-2 transition-all font-bold whitespace-nowrap text-xs md:text-sm">AI Tutor</span>
            </button>
            
            {!isQuizRunning && activeTab !== 'quiz' && !isFocusMode && onEnterPresentation && (
                <div className="absolute top-2 right-2 z-50 hidden md:block">
                    <button 
                        onClick={onEnterPresentation} 
                        className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-full shadow-lg transition-all"
                        title="Enter Presentation Mode"
                    >
                        <Monitor className="w-4 h-4" />
                        <span className="font-burmese text-sm pt-0.5 hidden sm:inline">Presentation</span>
                    </button>
                </div>
            )}
          </>
      )}

      {/* Optimized Header */}
      {!isFocusMode && (
        <div className="bg-white border-b border-slate-200 shadow-sm shrink-0">
         <div className="px-4 py-3 sm:px-6 sm:py-6 relative">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-3 mb-1">
                    <div className="text-3xl font-bold text-slate-800 font-burmese leading-tight hidden md:block">
                        {language === 'my' ? chapter.titleBurmese : chapter.titleEnglish}
                    </div>
                    {/* Mobile Title */}
                    <div className="text-xl font-bold text-slate-800 font-burmese leading-tight md:hidden">
                        {language === 'my' ? chapter.titleBurmese : chapter.titleEnglish}
                    </div>
                </div>
                <p className="text-sm font-medium text-slate-500 hidden sm:block">
                    {language === 'my' ? chapter.titleEnglish : chapter.titleBurmese}
                </p>
                {/* Mobile: Show English/Burmese sub-title if expanded, else hide to save space */}
                <div className="sm:hidden mt-1">
                    <button onClick={() => setIsHeaderExpanded(!isHeaderExpanded)} className="text-xs text-indigo-600 font-bold flex items-center gap-1">
                        <Info className="w-3 h-3" /> {isHeaderExpanded ? 'Hide Info' : 'Show Info'}
                    </button>
                    {isHeaderExpanded && (
                        <div className="mt-2 text-xs text-slate-500 animate-in slide-in-from-top-2">
                            <p className="mb-1 font-bold">{language === 'my' ? chapter.titleEnglish : chapter.titleBurmese}</p>
                            <p className="font-burmese leading-relaxed">{chapter.summary}</p>
                        </div>
                    )}
                </div>
                <p className="text-base font-burmese text-slate-600 mt-3 max-w-3xl leading-loose hidden sm:block">
                    {chapter.summary}
                </p>
              </div>
            </div>

            {/* Desktop Tabs */}
            <div className="flex items-center gap-1 mt-6 border-b border-slate-100 overflow-x-auto custom-scrollbar pb-1 hidden md:flex">
              {TABS.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => onTabChange(tab.id as any)}
                  className={`
                    flex items-center gap-2 px-4 py-2.5 text-sm font-bold rounded-t-lg transition-all relative
                    ${activeTab === tab.id 
                      ? 'text-indigo-600 bg-indigo-50/50 border-b-2 border-indigo-600' 
                      : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'}
                  `}
                >
                  <tab.icon className={`w-4 h-4 ${activeTab === tab.id ? 'text-indigo-600' : 'text-slate-400'}`} />
                  <span className={language === 'my' ? 'font-burmese pt-0.5' : ''}>
                      {language === 'my' ? tab.burmese : tab.label}
                  </span>
                  {tab.id === 'gallery' && chapterImages.length > 0 && (
                      <span className="bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded-full text-[10px]">{chapterImages.length}</span>
                  )}
                </button>
              ))}
            </div>
         </div>
        </div>
      )}

      {/* Mobile Sticky Tabs */}
      <div className={`md:hidden bg-white border-b border-slate-200 sticky top-0 z-40 shadow-sm flex overflow-x-auto custom-scrollbar px-2 ${isFocusMode ? 'hidden' : ''}`}>
          {TABS.map((tab) => (
            <button
                key={tab.id}
                onClick={() => { onTabChange(tab.id as any); window.scrollTo({top: 0, behavior: 'smooth'}); }}
                className={`
                flex-1 flex flex-col items-center justify-center py-3 min-w-[70px] relative
                ${activeTab === tab.id ? 'text-indigo-600' : 'text-slate-400'}
                `}
            >
                <tab.icon className="w-5 h-5 mb-1" />
                <span className={`text-[10px] font-bold whitespace-nowrap ${language === 'my' ? 'font-burmese' : ''}`}>
                    {language === 'my' ? tab.burmese : tab.label}
                </span>
                {activeTab === tab.id && (
                    <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-600 rounded-t-full mx-4"></div>
                )}
            </button>
          ))}
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-hidden relative">
        <div className="h-full overflow-y-auto custom-scrollbar p-4 sm:p-6 pb-24">
          
          {/* RESOURCES TAB (ASSIGNMENT WORKSPACE) */}
          {activeTab === 'resources' && (
              <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-300">
                  
                  {/* TEACHER MODE: CREATE & MANAGE */}
                  {!isReadOnly && (
                    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                        <div className="p-4 bg-indigo-50 border-b border-indigo-100 flex items-center justify-between">
                            <h3 className="font-bold text-indigo-900 flex items-center gap-2 font-burmese">
                                <HelpCircle className="w-5 h-5" /> Discussion Questions
                            </h3>
                            <span className="text-xs font-bold text-indigo-400 bg-white px-2 py-1 rounded border border-indigo-100">For AI Tutor</span>
                        </div>
                        
                        <div className="p-6">
                            {/* AI Generator Tool */}
                            <div className="mb-8 p-4 bg-slate-50 rounded-xl border border-slate-200">
                                <div className="flex items-center gap-2 mb-3 text-xs font-bold text-indigo-600 uppercase tracking-wider">
                                    <Sparkles className="w-4 h-4" /> Creation Tools
                                </div>
                                <div className="flex gap-2">
                                    <button 
                                        onClick={handleCopyDiscussionPromptOnly}
                                        className="flex-1 py-3 bg-white border border-indigo-200 text-indigo-600 hover:bg-indigo-50 rounded-lg font-bold text-sm flex items-center justify-center gap-2 transition-colors shadow-sm"
                                    >
                                        <Copy className="w-4 h-4" /> Copy Prompt Only
                                    </button>
                                    <button 
                                        onClick={handleOpenGemini}
                                        className="p-3 bg-white border border-slate-200 text-slate-500 hover:text-indigo-600 hover:bg-slate-50 rounded-lg transition-colors"
                                        title="Open Gemini in New Tab"
                                    >
                                        <ExternalLink className="w-4 h-4" />
                                    </button>
                                    <button 
                                        onClick={handlePasteDiscussionJson}
                                        className="flex-[2] py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-bold text-sm flex items-center justify-center gap-2 transition-colors shadow-md"
                                    >
                                        <ClipboardPaste className="w-4 h-4" /> Paste JSON
                                    </button>
                                </div>
                                {/* Hidden textarea for paste fallback */}
                                <textarea ref={discussionTextareaRef} className="sr-only" onChange={(e) => setDiscussionJsonInput(e.target.value)} value={discussionJsonInput} />
                            </div>

                            {/* Manual Add */}
                            <div className="flex gap-2 mb-6">
                                <input 
                                    type="text" 
                                    value={resourceForm.question}
                                    onChange={(e) => setResourceForm(prev => ({ ...prev, question: e.target.value }))}
                                    placeholder="Or type a question manually..."
                                    className="flex-1 p-3 bg-white text-slate-900 border border-slate-200 rounded-lg text-sm font-burmese focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none"
                                />
                                <button onClick={handleAddQuestion} className="p-3 bg-slate-800 text-white rounded-lg hover:bg-slate-700 transition-colors">
                                    <Plus className="w-5 h-5" />
                                </button>
                            </div>

                            {/* Question List (Teacher View) */}
                            <div className="space-y-2">
                                {(resources?.questions || []).map((q, idx) => (
                                    <div key={idx} className="group flex items-start gap-3 p-3 bg-white border border-slate-100 rounded-lg hover:border-indigo-200 hover:shadow-sm transition-all">
                                        <span className="flex-shrink-0 w-6 h-6 rounded-full bg-indigo-50 text-indigo-600 text-xs font-bold flex items-center justify-center mt-0.5">{idx + 1}</span>
                                        {editingQIndex === idx ? (
                                            <div className="flex-1 flex gap-2">
                                                <input className="flex-1 p-1 bg-white text-slate-900 border rounded text-sm font-burmese" value={editQText} onChange={(e) => setEditQText(e.target.value)} autoFocus />
                                                <button onClick={saveEditQuestion} className="p-1 text-green-600"><Check className="w-4 h-4"/></button>
                                            </div>
                                        ) : (
                                            <p className="flex-1 text-sm text-slate-700 font-burmese leading-relaxed cursor-pointer" onClick={() => startEditQuestion(idx, q)}>{q}</p>
                                        )}
                                        <button onClick={() => handleDeleteQuestion(idx)} className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-red-500 transition-opacity">
                                            <X className="w-4 h-4" />
                                        </button>
                                    </div>
                                ))}
                                {(resources?.questions || []).length === 0 && (
                                    <div className="text-center py-8 text-slate-400 border-2 border-dashed border-slate-100 rounded-lg text-sm">No discussion questions yet.</div>
                                )}
                            </div>
                        </div>
                    </div>
                  )}

                  {/* STUDENT MODE: ASSIGNMENT WORKSPACE */}
                  {isReadOnly && (
                      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                          <div className="p-6 border-b border-slate-100 bg-slate-50 flex flex-col md:flex-row md:items-center justify-between gap-4">
                              <div>
                                  <div className="flex items-center gap-2 mb-1">
                                      <FileText className="w-5 h-5 text-indigo-600" />
                                      <h3 className="font-bold text-slate-800 text-lg">Assignment Worksheet</h3>
                                  </div>
                                  <p className="text-sm text-slate-500">Reflect and write your answers</p>
                              </div>
                              <button 
                                  onClick={handleExportAssignment}
                                  className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-bold text-sm shadow-lg shadow-indigo-200 transition-all active:scale-95 flex items-center gap-2"
                              >
                                  <FileDown className="w-4 h-4" /> Export Assignment
                              </button>
                          </div>

                          {/* Student Name Input */}
                          <div className="p-6 border-b border-slate-100 bg-indigo-50/30">
                              <label className="block text-xs font-bold text-indigo-900 uppercase tracking-wider mb-2">Student Name (Required for Export)</label>
                              <input 
                                type="text" 
                                value={studentName}
                                onChange={(e) => setStudentName(e.target.value)}
                                placeholder="Enter your full name..."
                                className="w-full p-3 bg-white text-slate-900 border border-indigo-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none font-bold placeholder:font-normal"
                              />
                          </div>

                          <div className="p-6 bg-slate-50">
                              {/* Progress Bar */}
                              <div className="flex items-center justify-between text-xs font-bold text-slate-500 mb-2">
                                  <span>Progress</span>
                                  <span>{Object.keys(studentAnswers).length} / {(resources?.questions || []).length} Answered</span>
                              </div>
                              <div className="h-2 w-full bg-slate-200 rounded-full overflow-hidden mb-8">
                                  <div 
                                    className="h-full bg-indigo-500 transition-all duration-500 ease-out" 
                                    style={{ width: `${((Object.keys(studentAnswers).length) / Math.max(1, (resources?.questions || []).length)) * 100}%` }}
                                  ></div>
                              </div>

                              <div className="space-y-6">
                                  {(resources?.questions || []).map((q, idx) => (
                                      <div key={idx} className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden group hover:border-indigo-300 transition-colors">
                                          <div className="p-4 border-b border-slate-50 flex gap-3">
                                              <div className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-700 font-bold flex items-center justify-center shrink-0 text-sm mt-0.5">
                                                  {idx + 1}
                                              </div>
                                              <div>
                                                  <p className="text-slate-800 font-burmese leading-loose text-base font-medium">{q}</p>
                                                  <button 
                                                      onClick={() => handleAskAI(q)}
                                                      className="mt-2 text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 hover:underline"
                                                  >
                                                      <Bot className="w-3 h-3" /> Ask AI Tutor for help
                                                  </button>
                                              </div>
                                          </div>
                                          
                                          <div className="p-4 bg-slate-50/50">
                                              {studentAnswers[idx] ? (
                                                  <div className="relative group/answer">
                                                      <div 
                                                        className="p-4 bg-white text-slate-900 border border-slate-200 rounded-lg font-burmese leading-relaxed text-sm min-h-[80px] whitespace-pre-wrap cursor-pointer hover:bg-slate-50 transition-colors"
                                                        onClick={() => { setActiveQuestionIdx(idx); setIsFocusEditorOpen(true); }}
                                                      >
                                                          {studentAnswers[idx]}
                                                      </div>
                                                      <button 
                                                        onClick={() => { setActiveQuestionIdx(idx); setIsFocusEditorOpen(true); }}
                                                        className="absolute top-2 right-2 p-1.5 bg-white border border-slate-200 rounded-md text-slate-400 hover:text-indigo-600 shadow-sm opacity-0 group-hover/answer:opacity-100 transition-opacity"
                                                        title="Edit Answer"
                                                      >
                                                          <PenLine className="w-4 h-4" />
                                                      </button>
                                                  </div>
                                              ) : (
                                                  <button 
                                                    onClick={() => { setActiveQuestionIdx(idx); setIsFocusEditorOpen(true); }}
                                                    className="w-full py-8 border-2 border-dashed border-slate-300 rounded-lg text-slate-400 hover:border-indigo-400 hover:text-indigo-600 hover:bg-indigo-50/30 transition-all flex flex-col items-center gap-2 font-medium text-sm"
                                                  >
                                                      <PenLine className="w-5 h-5" />
                                                      <span>Write your answer here...</span>
                                                  </button>
                                              )}
                                          </div>
                                      </div>
                                  ))}
                              </div>
                          </div>
                      </div>
                  )}

                  {/* External Links Section */}
                  <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                      <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2 font-burmese">
                          <LinkIcon className="w-5 h-5 text-slate-400" /> Links & Media
                      </h3>
                      {!isReadOnly && (
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6 p-4 bg-slate-50 rounded-xl border border-slate-100">
                              <div className="space-y-3">
                                  <label className="text-xs font-bold text-slate-500 uppercase">Embed Media</label>
                                  <input placeholder="YouTube URL" className="w-full p-2 bg-white text-slate-900 text-sm border rounded" value={resourceForm.youtube} onChange={(e) => setResourceForm(prev => ({...prev, youtube: e.target.value}))} />
                                  <input placeholder="Audio URL" className="w-full p-2 bg-white text-slate-900 text-sm border rounded" value={resourceForm.audio} onChange={(e) => setResourceForm(prev => ({...prev, audio: e.target.value}))} />
                              </div>
                              <div className="space-y-3">
                                  <label className="text-xs font-bold text-slate-500 uppercase">Add Reference Link</label>
                                  <input placeholder="Link Title" className="w-full p-2 bg-white text-slate-900 text-sm border rounded" value={resourceForm.linkTitle} onChange={(e) => setResourceForm(prev => ({...prev, linkTitle: e.target.value}))} />
                                  <div className="flex gap-2">
                                      <input placeholder="Link URL" className="w-full p-2 bg-white text-slate-900 text-sm border rounded" value={resourceForm.linkUrl} onChange={(e) => setResourceForm(prev => ({...prev, linkUrl: e.target.value}))} />
                                      <button onClick={handleAddLink} className="bg-slate-800 text-white px-4 rounded text-sm font-bold">Add</button>
                                  </div>
                              </div>
                              <div className="md:col-span-2 pt-2">
                                  <button onClick={handleSaveResources} className="w-full py-2 bg-indigo-600 text-white rounded font-bold text-sm">Save All</button>
                              </div>
                          </div>
                      )}
                      
                      <div className="space-y-3">
                          {resources?.youtube && (
                              <a href={resources.youtube} target="_blank" rel="noreferrer" className="flex items-center gap-3 p-3 bg-red-50 text-red-700 rounded-lg border border-red-100 hover:bg-red-100 transition-colors">
                                  <Youtube className="w-5 h-5" /> <span className="font-medium text-sm">Watch Video Lesson</span>
                              </a>
                          )}
                          {resources?.audio && (
                              <a href={resources.audio} target="_blank" rel="noreferrer" className="flex items-center gap-3 p-3 bg-purple-50 text-purple-700 rounded-lg border border-purple-100 hover:bg-purple-100 transition-colors">
                                  <Music className="w-5 h-5" /> <span className="font-medium text-sm">Listen to Audio Lecture</span>
                              </a>
                          )}
                          {(resources?.links || []).map((link, i) => (
                              <div key={i} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-100 hover:border-indigo-200 transition-colors">
                                  <a href={link.url} target="_blank" rel="noreferrer" className="flex items-center gap-3 text-indigo-600 font-medium text-sm hover:underline">
                                      <ExternalLink className="w-4 h-4" /> {link.title}
                                  </a>
                                  {!isReadOnly && (
                                      <button onClick={() => handleRemoveLink(i)} className="text-slate-400 hover:text-red-500"><X className="w-4 h-4" /></button>
                                  )}
                              </div>
                          ))}
                      </div>
                  </div>
              </div>
          )}

          {activeTab === 'quiz' && (
            <div className="max-w-3xl mx-auto space-y-6">
                {!isReadOnly && (
                    <div className="bg-white p-6 rounded-xl border border-indigo-100 shadow-sm">
                        <div className="flex items-center gap-2 mb-4 text-indigo-800 font-bold">
                            <Bot className="w-5 h-5" />
                            <span>Manage Quiz (Teacher)</span>
                        </div>
                        
                        <div className="space-y-4">
                            <div className="bg-indigo-50 p-4 rounded-lg border border-indigo-100">
                                <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider mb-2 block font-burmese">Step 1: Generate with Gemini</span>
                                <p className="text-sm text-indigo-800 mb-3 leading-relaxed">Copy this prompt and paste it into your Gemini Gem to get valid JSON.</p>
                                <div className="flex gap-2">
                                    <button 
                                        onClick={handleCopyPromptOnly} 
                                        className="flex-1 py-2 bg-white text-indigo-600 border border-indigo-200 hover:bg-indigo-50 rounded-lg text-xs font-bold shadow-sm transition-all flex items-center justify-center gap-2"
                                    >
                                        <Copy className="w-3.5 h-3.5" /> Copy Prompt Only
                                    </button>
                                    <button 
                                        onClick={handleCopyAndOpenGemini}
                                        className="flex-1 py-2 bg-indigo-600 text-white hover:bg-indigo-700 rounded-lg text-xs font-bold shadow-sm transition-all flex items-center justify-center gap-2"
                                    >
                                        <ExternalLink className="w-3.5 h-3.5" /> Copy & Open Gemini
                                    </button>
                                </div>
                            </div>

                            <div>
                                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 block font-burmese">Step 2: Upload or Paste JSON</span>
                                <div className="flex gap-2 mb-2">
                                    <label className="flex-1 cursor-pointer bg-slate-100 hover:bg-slate-200 text-slate-600 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-colors">
                                        <Upload className="w-3.5 h-3.5" /> Upload .json File
                                        <input type="file" accept=".json" onChange={handleQuizJsonUpload} className="hidden" />
                                    </label>
                                    <button 
                                        onClick={handlePasteFromClipboard}
                                        className="flex-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-600 border border-indigo-200 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-colors"
                                    >
                                        <ClipboardPaste className="w-3.5 h-3.5" /> Paste from Clipboard
                                    </button>
                                </div>
                                <textarea 
                                    ref={quizJsonTextareaRef}
                                    value={quizJsonInput}
                                    onChange={(e) => setQuizJsonInput(e.target.value)}
                                    placeholder="Or paste the JSON array here..."
                                    className="w-full p-3 text-xs font-mono bg-slate-900 text-green-400 rounded-lg h-24 focus:ring-2 focus:ring-indigo-500 outline-none resize-none"
                                />
                            </div>
                            
                            <button 
                                onClick={handlePasteQuizJson}
                                disabled={!quizJsonInput.trim()}
                                className="w-full py-3 bg-slate-700 hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg font-bold text-sm transition-all"
                            >
                                Save JSON Quiz
                            </button>
                        </div>
                    </div>
                )}

                <div className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden">
                    <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-8 text-center text-white">
                        <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4 backdrop-blur-sm">
                            <GraduationCap className="w-8 h-8 text-white" />
                        </div>
                        <h3 className="text-2xl font-bold font-burmese mb-2">
                            {quiz ? (language === 'my' ? "လေ့ကျင့်ခန်း ဖြေဆိုရန်" : "Ready for Quiz") : "No Quiz Available"}
                        </h3>
                        <p className="text-indigo-100 font-burmese text-sm max-w-md mx-auto leading-relaxed">
                            {quiz 
                                ? (language === 'my' ? "သင်ခန်းစာကို နားလည်သဘောပေါက်မှု ရှိမရှိ စစ်ဆေးနိုင်ပါသည်။" : "Test your understanding of this chapter.") 
                                : "Teacher has not added a quiz yet."}
                        </p>
                    </div>
                    
                    {quiz ? (
                        <div className="p-8">
                            <div className="flex items-center justify-between text-sm text-slate-500 mb-8 px-4 py-3 bg-slate-50 rounded-lg border border-slate-100">
                                <span className="flex items-center gap-2"><HelpCircle className="w-4 h-4"/> {quiz.questions.length} Questions</span>
                                <span className="flex items-center gap-2"><Clock className="w-4 h-4"/> ~5 Mins</span>
                            </div>
                            <button 
                                onClick={() => setIsQuizRunning(true)}
                                className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-lg shadow-xl shadow-indigo-200 hover:shadow-2xl hover:-translate-y-1 transition-all active:scale-95 flex items-center justify-center gap-3 group"
                            >
                                Start Quiz <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                            </button>
                        </div>
                    ) : (
                        <div className="p-12 text-center text-slate-400">
                            <p className="font-burmese">No quiz available for this chapter yet.</p>
                        </div>
                    )}
                </div>
            </div>
          )}

          {activeTab === 'content' && renderNotesPanel()}
          {activeTab === 'visual' && renderVisualPanel()}
          {activeTab === 'gallery' && (
            <div className="max-w-7xl mx-auto animate-in fade-in zoom-in-95 duration-300">
              <Suspense fallback={<TabLoader />}>
                <ImageGallery 
                    chapterId={chapter.id} 
                    images={chapterImages} 
                    onAddImage={onAddImage} 
                    onRemoveImage={onRemoveImage}
                    onBulkRemoveImage={onBulkRemoveImage}
                    onReorderImages={onReorderImages}
                    onMoveToVisualAid={(img) => onAddDiagram(img)}
                    onBulkMoveToVisual={onBulkMoveToVisual}
                    isPresentationMode={isPresentationMode}
                    isReadOnly={isReadOnly}
                    showToast={showToast}
                />
              </Suspense>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
