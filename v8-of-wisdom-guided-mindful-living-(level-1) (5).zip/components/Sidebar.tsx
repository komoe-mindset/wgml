import React, { useRef, useState, memo } from 'react';
import { CHAPTERS } from '../constants';
import { Flower, Menu, Upload, Save, GraduationCap, UserCog, Settings, RotateCcw, ArrowLeft, ChevronLeft, Trash2, AlertTriangle, HelpCircle, Download } from 'lucide-react';

interface Props {
  activeChapterId: number;
  onSelectChapter: (id: number) => void;
  isOpen: boolean;
  toggleSidebar: () => void;
  onExport: () => void;
  onImport: (file: File) => void;
  onFactoryReset?: () => void;
  isStudentMode: boolean; 
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
  language: 'my' | 'en';
  onOpenGuide: () => void;
  installPrompt?: any;
  onInstallApp?: () => void;
}

export const Sidebar: React.FC<Props> = memo(({ 
  activeChapterId, 
  onSelectChapter, 
  isOpen, 
  toggleSidebar,
  onExport,
  onImport,
  onFactoryReset,
  isStudentMode,
  showToast,
  language,
  onOpenGuide,
  installPrompt,
  onInstallApp
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [newPin, setNewPin] = useState('');
  const [isConfirmingReset, setIsConfirmingReset] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onImport(e.target.files[0]);
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleChangePin = () => {
    if (newPin.length < 4) {
      showToast(language === 'my' ? "PIN အနည်းဆုံး ၄ လုံး ရှိရပါမည်" : "PIN must be at least 4 digits", 'error');
      return;
    }
    localStorage.setItem('teacher_pin', newPin);
    showToast(language === 'my' ? "PIN ပြောင်းလဲပြီးပါပြီ" : "PIN changed successfully!", 'success');
    setNewPin('');
    setShowSettings(false);
  };
  
  const handleResetClick = () => {
    if (isConfirmingReset) {
      // Confirmed action
      if (onFactoryReset) {
          onFactoryReset();
      } else {
          showToast("Reset function not available", 'error');
      }
      setIsConfirmingReset(false);
    } else {
      // First click - show confirmation
      setIsConfirmingReset(true);
      // Auto-cancel confirmation after 5 seconds
      setTimeout(() => setIsConfirmingReset(false), 5000);
    }
  };

  return (
    <>
      {/* Mobile Overlay */}
      <div 
        className={`fixed inset-0 bg-black/50 z-30 lg:hidden transition-opacity ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={toggleSidebar}
        aria-hidden="true"
      />

      {/* Sidebar Container */}
      <div className={`
        fixed lg:static inset-y-0 left-0 z-40
        w-80 bg-slate-900 text-slate-100 flex flex-col
        transform transition-transform duration-300 ease-in-out shadow-2xl
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
        ${!isOpen ? 'lg:w-0 lg:overflow-hidden' : ''}
      `}
      role="navigation"
      aria-label="Main Navigation"
      >
        {/* Logo / Header - Updated for Cleaner UI */}
        <div className="min-h-[6rem] py-4 px-6 border-b border-slate-800 flex items-center justify-between shrink-0 bg-slate-900/50 backdrop-blur-sm">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20 shrink-0 self-start mt-1">
              <Flower className="text-white w-5 h-5" />
            </div>
            <div className="flex flex-col">
              {language === 'my' ? (
                <>
                    <h1 className="font-bold font-burmese text-base text-indigo-50 leading-[1.6]">
                        ဉာဏ်ယှဉ်သတိဖြင့်<br/>နေထိုင်ခြင်း
                    </h1>
                    <p className="text-[10px] serif-title text-indigo-300 tracking-wide mt-1">
                        Wisdom-Guided Mindful Living
                    </p>
                </>
              ) : (
                <>
                    <h1 className="font-bold serif-title text-base text-indigo-50 leading-tight">
                        Wisdom-Guided<br/>Living
                    </h1>
                    <p className="text-[10px] font-burmese text-indigo-300 tracking-wide mt-1 leading-[1.6]">
                        ဉာဏ်ယှဉ်သတိဖြင့် နေထိုင်ခြင်း
                    </p>
                </>
              )}
            </div>
          </div>
          
          {/* Collapse Button (Small Icon in Header) */}
          <button 
            onClick={toggleSidebar}
            className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-800 hover:text-white transition-colors hidden lg:block shrink-0 self-start mt-1"
            title="Hide Sidebar"
            aria-label="Hide Sidebar"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
        </div>

        {/* User Profile Card */}
        <div className="px-6 py-4 bg-slate-800/30 border-b border-slate-800">
          <div className="flex items-center justify-between">
             <div className="flex items-center gap-3">
                <div className={`p-2 rounded-full ${isStudentMode ? 'bg-green-500/20 text-green-400' : 'bg-indigo-500/20 text-indigo-400'}`}>
                  {isStudentMode ? <GraduationCap className="w-5 h-5" /> : <UserCog className="w-5 h-5" />}
                </div>
                <div>
                  <p className="text-xs text-slate-400 uppercase font-bold">
                    {language === 'my' ? 'အကောင့်' : 'Logged in as (အကောင့်)'}
                  </p>
                  <p className={`font-bold text-sm text-white ${language === 'my' ? 'font-burmese leading-loose' : ''}`}>
                    {language === 'my' 
                        ? (isStudentMode ? 'ကျောင်းသား (Student)' : 'ဆရာ (Teacher)')
                        : (isStudentMode ? 'Student (ကျောင်းသား)' : 'Teacher (ဆရာ)')}
                  </p>
                </div>
             </div>
             <button 
                onClick={() => { setShowSettings(!showSettings); setIsConfirmingReset(false); }} 
                className={`p-2 rounded-lg transition-colors ${showSettings ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`}
                title="Settings"
                aria-label="Settings"
             >
               <Settings className="w-5 h-5" />
             </button>
          </div>
        </div>
        
        {/* User Guide & Install Buttons */}
        <div className="px-6 py-2 flex flex-col gap-1">
            <button 
                onClick={onOpenGuide}
                className="w-full flex items-center gap-3 px-3 py-2 text-sm text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition-all border border-transparent hover:border-slate-700"
            >
                <HelpCircle className="w-4 h-4 text-indigo-400" />
                <span className="font-burmese">
                    {language === 'my' ? 'လမ်းညွှန် (User Guide)' : 'User Guide'}
                </span>
            </button>
            {installPrompt && (
              <button 
                  onClick={onInstallApp}
                  className="w-full flex items-center gap-3 px-3 py-2 text-sm text-emerald-400 hover:text-emerald-300 hover:bg-emerald-950/30 rounded-lg transition-all border border-transparent hover:border-emerald-900 animate-in fade-in"
              >
                  <Download className="w-4 h-4" />
                  <span className="font-bold">Install App</span>
              </button>
            )}
        </div>

        {/* Navigation List */}
        <div className="flex-1 overflow-y-auto py-4 custom-scrollbar">
          <div className={`px-6 mb-3 text-xs font-bold text-slate-500 uppercase tracking-wider ${language === 'my' ? 'font-burmese leading-loose' : ''}`}>
             {language === 'my' ? 'မာတိကာ (Table of Contents)' : 'Table of Contents (မာတိကာ)'}
          </div>
          <nav className="space-y-1 px-3">
            {CHAPTERS.map((chapter) => (
              <button
                key={chapter.id}
                onClick={() => {
                  onSelectChapter(chapter.id);
                  if (window.innerWidth < 1024) toggleSidebar();
                }}
                className={`
                  w-full text-left px-3 py-3 rounded-lg text-sm transition-all duration-200 group
                  flex flex-col gap-1 relative mb-1 h-auto min-h-[3.5rem]
                  ${activeChapterId === chapter.id 
                    ? 'bg-indigo-600 text-white shadow-md' 
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'}
                `}
                aria-current={activeChapterId === chapter.id ? 'page' : undefined}
              >
                <div className="flex items-start justify-between w-full">
                  <span className={`font-medium text-base block w-full ${language === 'my' ? 'font-burmese leading-[2.2]' : ''}`}>
                    {language === 'my' ? chapter.titleBurmese : chapter.titleEnglish}
                  </span>
                  {activeChapterId === chapter.id && <div className="w-1.5 h-1.5 rounded-full bg-white shadow-sm shrink-0 mt-2 ml-2" />}
                </div>
                <span className={`text-xs ${activeChapterId === chapter.id ? 'text-indigo-200' : 'text-slate-500 group-hover:text-slate-400'} ${language !== 'my' ? 'font-burmese' : ''}`}>
                  {language === 'my' ? chapter.titleEnglish : chapter.titleBurmese}
                </span>
              </button>
            ))}
          </nav>
        </div>

        {/* Settings Panel (Teacher Only) */}
        {!isStudentMode && showSettings && (
          <div className="mx-4 mb-4 p-4 bg-slate-800 rounded-xl border border-slate-700 animate-in slide-in-from-bottom-5 shadow-2xl">
             <div className="flex items-center justify-between mb-3">
                 <h3 className="text-sm font-bold text-white flex items-center gap-2">
                   <Settings className="w-4 h-4" /> {language === 'my' ? 'ဆက်တင်' : 'Settings (ဆက်တင်)'}
                 </h3>
                 <button onClick={() => setShowSettings(false)} className="text-slate-400 hover:text-white" aria-label="Close Settings">
                    <ChevronLeft className="w-4 h-4 rotate-[-90deg]" />
                 </button>
             </div>
             
             <div className="space-y-4">
               <div>
                 <label htmlFor="new-pin" className="text-xs text-slate-400 mb-1 block">{language === 'my' ? 'PIN ပြောင်းရန်' : 'Change Login PIN'}</label>
                 <div className="flex gap-2">
                   <input 
                     id="new-pin"
                     type="password" 
                     placeholder="New PIN" 
                     value={newPin}
                     onChange={(e) => setNewPin(e.target.value)}
                     className="bg-slate-900 border border-slate-700 rounded px-2 py-1 text-sm text-white w-full focus:outline-none focus:border-indigo-500"
                   />
                   <button 
                     onClick={handleChangePin}
                     className="bg-indigo-600 px-3 py-1 rounded text-xs font-bold hover:bg-indigo-500 text-white"
                   >
                     {language === 'my' ? 'သိမ်းမည်' : 'Save'}
                   </button>
                 </div>
               </div>

               <div className="border-t border-slate-700 pt-3">
                   {isConfirmingReset ? (
                       <div className="space-y-2 animate-in fade-in zoom-in-95 duration-200">
                           <div className="p-2 bg-red-950/50 border border-red-900/50 rounded flex items-start gap-2 text-[10px] text-red-200">
                               <AlertTriangle className="w-4 h-4 text-red-500 shrink-0" />
                               <span>
                                   {language === 'my' 
                                    ? 'သတိပေးချက်: အချက်အလက်များအားလုံး (မှတ်စု၊ ပုံများ) ပျက်သွားပါမည်။' 
                                    : 'Warning: This will delete ALL uploaded images, notes, and data. This cannot be undone.'}
                               </span>
                           </div>
                           <button 
                            onClick={handleResetClick}
                            className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-red-600 hover:bg-red-700 text-white border border-red-500 rounded-lg text-xs font-bold transition-colors shadow-lg shadow-red-900/30"
                           >
                               <Trash2 className="w-3 h-3" /> {language === 'my' ? 'အားလုံးဖျက်မည်' : 'CONFIRM DELETE ALL'}
                           </button>
                           <button 
                             onClick={() => setIsConfirmingReset(false)}
                             className="w-full text-center text-[10px] text-slate-500 hover:text-slate-300 underline"
                           >
                             {language === 'my' ? 'မလုပ်တော့ပါ' : 'Cancel'}
                           </button>
                       </div>
                   ) : (
                       <button 
                        onClick={handleResetClick}
                        className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-red-950/30 hover:bg-red-900/40 text-red-400 border border-red-900/30 hover:border-red-800 rounded-lg text-xs font-bold transition-all"
                       >
                           <Trash2 className="w-3 h-3" /> {language === 'my' ? 'Data အစကပြန်စမည် (Factory Reset)' : 'Factory Reset Data'}
                       </button>
                   )}
               </div>
             </div>
          </div>
        )}
      </div>
    </>
  );
});