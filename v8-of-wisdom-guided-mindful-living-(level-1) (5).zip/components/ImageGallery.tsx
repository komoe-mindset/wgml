
import React, { useState, useRef, useEffect } from 'react';
import { Upload, X, Image as ImageIcon, Maximize2, Trash2, MoveLeft, MoveRight, CheckSquare, Square, GripVertical, Download, Move, BookOpen, ChevronLeft, ChevronRight, GripHorizontal } from 'lucide-react';
import { processImage } from '../utils/imageProcessor';

interface Props {
  chapterId: number;
  images: string[];
  onAddImage: (img: string | string[]) => void;
  onRemoveImage: (index: number) => void;
  onBulkRemoveImage?: (indices: number[]) => void;
  onReorderImages?: (newImages: string[]) => void;
  onMoveToVisualAid?: (image: string) => void;
  onBulkMoveToVisual?: (indices: number[]) => void;
  isPresentationMode: boolean;
  isReadOnly?: boolean; 
  showToast?: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const ImageGallery: React.FC<Props> = ({ 
  chapterId, 
  images, 
  onAddImage, 
  onRemoveImage,
  onBulkRemoveImage,
  onReorderImages,
  onMoveToVisualAid,
  onBulkMoveToVisual,
  isPresentationMode,
  isReadOnly = false,
  showToast
}) => {
  // Changed from storing URL string to storing Index number for navigation
  const [fullscreenIndex, setFullscreenIndex] = useState<number | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedImages, setSelectedImages] = useState<number[]>([]);
  const [isSelectionMode, setIsSelectionMode] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isConfirmingDelete, setIsConfirmingDelete] = useState(false);
  const [deletingImageIndex, setDeletingImageIndex] = useState<number | null>(null);
  
  // Drag and Drop State
  const [draggedImageIndex, setDraggedImageIndex] = useState<number | null>(null);

  // Keyboard Navigation for Lightbox
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (fullscreenIndex === null) return;

      if (e.key === 'ArrowRight') {
        e.preventDefault();
        handleNextImage();
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        handlePrevImage();
      } else if (e.key === 'Escape') {
        e.preventDefault();
        setFullscreenIndex(null);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [fullscreenIndex, images.length]);

  const handleNextImage = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (fullscreenIndex !== null) {
      setFullscreenIndex((prev) => (prev !== null ? (prev + 1) % images.length : null));
    }
  };

  const handlePrevImage = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (fullscreenIndex !== null) {
      setFullscreenIndex((prev) => (prev !== null ? (prev - 1 + images.length) % images.length : null));
    }
  };

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files.length > 0) {
      try {
        setIsProcessing(true);
        const processingPromises = Array.from(files).map(file => processImage(file as File));
        const optimizedImages = await Promise.all(processingPromises);
        
        // Bulk add
        onAddImage(optimizedImages);
        
      } catch (error) {
        console.error("Image processing failed:", error);
        if (showToast) showToast("Failed to process some images.", 'error');
      } finally {
        setIsProcessing(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    }
  };

  const toggleSelection = (idx: number) => {
    if (selectedImages.includes(idx)) {
        setSelectedImages(prev => prev.filter(i => i !== idx));
    } else {
        setSelectedImages(prev => [...prev, idx]);
    }
  };

  const handleBulkDelete = () => {
      if (selectedImages.length === 0) return;
      
      if (isConfirmingDelete) {
          if (onBulkRemoveImage) {
            onBulkRemoveImage(selectedImages);
          } else {
            const sortedIndices = [...selectedImages].sort((a, b) => b - a);
            sortedIndices.forEach(idx => onRemoveImage(idx));
          }
          setSelectedImages([]);
          setIsSelectionMode(false);
          setIsConfirmingDelete(false);
      } else {
          setIsConfirmingDelete(true);
          setTimeout(() => setIsConfirmingDelete(false), 3000);
      }
  };

  const handleBulkMove = () => {
      if (selectedImages.length === 0) return;
      if (onBulkMoveToVisual) {
          onBulkMoveToVisual(selectedImages);
          setSelectedImages([]);
          setIsSelectionMode(false);
      }
  };

  const handleMoveImage = (fromIndex: number, direction: 'left' | 'right') => {
      if (!onReorderImages) return;
      const toIndex = direction === 'left' ? fromIndex - 1 : fromIndex + 1;
      if (toIndex < 0 || toIndex >= images.length) return;

      const newImages = [...images];
      const [movedItem] = newImages.splice(fromIndex, 1);
      newImages.splice(toIndex, 0, movedItem);
      onReorderImages(newImages);
  };

  // --- DRAG AND DROP HANDLERS ---
  const handleDragStart = (e: React.DragEvent, index: number) => {
      setDraggedImageIndex(index);
      e.dataTransfer.effectAllowed = "move";
      // Optional: Set a custom drag image ghost here if needed
  };

  const handleDragOver = (e: React.DragEvent, index: number) => {
      e.preventDefault(); // Necessary to allow dropping
      e.dataTransfer.dropEffect = "move";
  };

  const handleDrop = (e: React.DragEvent, dropIndex: number) => {
      e.preventDefault();
      if (draggedImageIndex === null || draggedImageIndex === dropIndex) return;

      if (onReorderImages) {
          const newImages = [...images];
          const [movedItem] = newImages.splice(draggedImageIndex, 1);
          newImages.splice(dropIndex, 0, movedItem);
          onReorderImages(newImages);
          if(showToast) showToast("Image reordered");
      }
      setDraggedImageIndex(null);
  };

  return (
    <div className="space-y-6">
      
      {/* Teacher Toolbar */}
      {!isPresentationMode && !isReadOnly && (
        <div className="flex flex-col gap-2">
            <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200 sticky top-0 z-10 shadow-sm">
                <div className="flex gap-2 items-center flex-wrap">
                    <button 
                        onClick={() => { setIsSelectionMode(!isSelectionMode); setSelectedImages([]); setIsConfirmingDelete(false); setDeletingImageIndex(null); }}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-2 transition-colors ${isSelectionMode ? 'bg-indigo-600 text-white shadow-md' : 'bg-white border border-slate-300 text-slate-600 hover:bg-slate-100'}`}
                    >
                        {isSelectionMode ? <CheckSquare className="w-4 h-4" /> : <Square className="w-4 h-4" />}
                        {isSelectionMode ? 'Exit Selection' : 'Select Images'}
                    </button>
                    
                    {isSelectionMode && selectedImages.length > 0 && (
                        <div className="flex gap-2 animate-in fade-in slide-in-from-left-2">
                            <div className="w-px h-6 bg-slate-300 mx-1 self-center"></div>
                            <button 
                                onClick={handleBulkMove}
                                className="px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-2 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 border border-indigo-200 transition-colors"
                                title="Move selected images to Visual Aid slides"
                            >
                                <BookOpen className="w-4 h-4" /> To Visual Aid
                            </button>
                            <button 
                                onClick={handleBulkDelete}
                                className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-2 transition-colors border ${
                                    isConfirmingDelete
                                    ? 'bg-red-600 text-white border-red-600 hover:bg-red-700 animate-pulse'
                                    : 'bg-red-50 text-red-600 hover:bg-red-100 border-red-200'
                                }`}
                            >
                                <Trash2 className="w-4 h-4" /> 
                                {isConfirmingDelete ? 'Confirm?' : `Delete (${selectedImages.length})`}
                            </button>
                        </div>
                    )}
                </div>

                <div 
                onClick={() => !isProcessing && fileInputRef.current?.click()}
                className={`
                    flex items-center gap-2 px-4 py-2 bg-white hover:bg-indigo-50 text-indigo-600 rounded-lg cursor-pointer border border-indigo-200 transition-colors shadow-sm
                    ${isProcessing ? 'opacity-50 cursor-wait' : ''}
                `}
                >
                <input 
                    type="file" 
                    ref={fileInputRef} 
                    onChange={handleFileChange} 
                    accept="image/png, image/jpeg, image/jpg" 
                    multiple
                    className="hidden" 
                />
                {isProcessing ? (
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-indigo-600"></div>
                ) : (
                    <Upload className="w-4 h-4" />
                )}
                <span className="text-xs font-bold">Upload Images</span>
                </div>
            </div>
            
            {/* Drag Hint */}
            {images.length > 1 && (
                <div className="bg-indigo-50/50 border border-indigo-100 rounded-lg py-1 px-3 flex items-center justify-center gap-2 text-[10px] text-indigo-400 font-bold uppercase tracking-wider">
                    <GripHorizontal className="w-3 h-3" />
                    Drag images to reorder
                </div>
            )}
        </div>
      )}

      {/* Gallery Grid */}
      {images.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {images.map((img, idx) => (
            <div 
              key={idx} 
              draggable={!isReadOnly && !isSelectionMode && deletingImageIndex !== idx}
              onDragStart={(e) => handleDragStart(e, idx)}
              onDragOver={(e) => handleDragOver(e, idx)}
              onDrop={(e) => handleDrop(e, idx)}
              className={`
                group relative rounded-xl overflow-hidden border bg-white aspect-video 
                transition-all duration-300
                ${selectedImages.includes(idx) ? 'ring-4 ring-indigo-500 border-indigo-500 shadow-md transform scale-[0.98]' : 'border-slate-200 shadow-sm'}
                ${isPresentationMode || isReadOnly ? 'cursor-zoom-in hover:shadow-xl hover:scale-[1.02]' : ''}
                ${draggedImageIndex === idx ? 'opacity-40 scale-95 border-dashed border-indigo-400' : ''}
                ${!isReadOnly && !isSelectionMode && draggedImageIndex !== null && draggedImageIndex !== idx ? 'hover:border-indigo-400 hover:ring-2 hover:ring-indigo-200' : ''}
                ${!isReadOnly && !isSelectionMode && deletingImageIndex !== idx ? 'cursor-grab active:cursor-grabbing' : ''}
              `}
              onClick={() => {
                  if (deletingImageIndex === idx) return;
                  if (isSelectionMode) toggleSelection(idx);
                  else if (isPresentationMode || isReadOnly) setFullscreenIndex(idx);
              }}
            >
              <img 
                src={img} 
                alt={`Infographic ${idx + 1}`} 
                className="w-full h-full object-cover pointer-events-none" 
              />
              
              {/* Single Image Delete Confirmation Overlay */}
              {!isReadOnly && deletingImageIndex === idx && (
                  <div className="absolute inset-0 bg-red-600/90 flex flex-col items-center justify-center gap-3 p-4 z-20 animate-in fade-in zoom-in-95 backdrop-blur-sm" onClick={(e) => e.stopPropagation()}>
                      <p className="text-white font-bold text-sm drop-shadow-md">Delete this image?</p>
                      <div className="flex gap-2">
                          <button 
                              onClick={(e) => { e.stopPropagation(); onRemoveImage(idx); setDeletingImageIndex(null); }}
                              className="px-4 py-2 bg-white text-red-600 rounded-lg text-xs font-bold hover:bg-red-50 transition-colors shadow-lg"
                          >
                              Yes, Delete
                          </button>
                          <button 
                              onClick={(e) => { e.stopPropagation(); setDeletingImageIndex(null); }}
                              className="px-4 py-2 bg-red-800/50 text-white rounded-lg text-xs font-bold hover:bg-red-800 transition-colors shadow-lg border border-red-400"
                          >
                              Cancel
                          </button>
                      </div>
                  </div>
              )}

              {/* Selection Overlay */}
              {isSelectionMode && (
                  <div className={`absolute inset-0 bg-black/10 flex items-start justify-end p-2 cursor-pointer ${selectedImages.includes(idx) ? 'bg-indigo-500/20' : 'hover:bg-black/20'}`}>
                      <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${selectedImages.includes(idx) ? 'bg-indigo-600 border-indigo-600 text-white scale-110' : 'bg-white border-slate-300'}`}>
                          {selectedImages.includes(idx) && <CheckSquare className="w-4 h-4" />}
                      </div>
                  </div>
              )}

              {/* Hover Controls (Teacher Normal Mode) */}
              {!isPresentationMode && !isReadOnly && !isSelectionMode && deletingImageIndex !== idx && (
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/60 transition-all flex flex-col items-center justify-center gap-3 opacity-0 group-hover:opacity-100">
                  
                  {/* Drag Handle Indicator */}
                  <div className="absolute top-2 left-1/2 -translate-x-1/2 text-white/50">
                      <GripHorizontal className="w-6 h-6" />
                  </div>

                  <div className="flex gap-2">
                      <button 
                        onClick={(e) => { e.stopPropagation(); setFullscreenIndex(idx); }}
                        className="p-2 bg-white/90 rounded-full hover:bg-white text-indigo-600 transition-transform hover:scale-110"
                        title="View Fullscreen"
                      >
                        <Maximize2 className="w-5 h-5" />
                      </button>
                      
                      <button 
                        onClick={(e) => { e.stopPropagation(); setDeletingImageIndex(idx); }}
                        className="p-2 bg-white/90 rounded-full hover:bg-red-50 text-red-500 transition-transform hover:scale-110"
                        title="Delete"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                  </div>

                  {/* Move to Visual Aid Button */}
                  {onMoveToVisualAid && (
                      <button
                          onClick={(e) => { e.stopPropagation(); onMoveToVisualAid(img); if (showToast) showToast("Copied to Visual Aid"); }}
                          className="mt-2 px-3 py-1 bg-indigo-600 hover:bg-indigo-500 text-white text-xs rounded-full flex items-center gap-1 font-bold shadow-lg"
                      >
                          <Move className="w-3 h-3" /> Use as Visual Aid
                      </button>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-12 text-slate-400 bg-slate-50/50 rounded-xl border border-dashed border-slate-200">
          <ImageIcon className="w-12 h-12 mx-auto mb-3 opacity-20" />
          <p className="font-burmese text-lg opacity-60">No images yet</p>
        </div>
      )}

      {/* Lightbox / Fullscreen Viewer */}
      {fullscreenIndex !== null && (
        <div 
          className="fixed inset-0 z-[100] bg-black/95 flex items-center justify-center p-4 backdrop-blur-md animate-in fade-in duration-200"
          onClick={() => setFullscreenIndex(null)}
        >
          {/* Close Button */}
          <button 
            onClick={() => setFullscreenIndex(null)}
            className="absolute top-4 right-4 sm:top-6 sm:right-6 p-3 bg-white/10 text-white rounded-full hover:bg-white/20 transition-all hover:rotate-90 z-50"
            title="Close (Esc)"
          >
            <X className="w-6 h-6" />
          </button>

          {/* Navigation Controls */}
          {images.length > 1 && (
             <>
                <button 
                  onClick={handlePrevImage}
                  className="absolute left-4 sm:left-8 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-all z-50"
                  title="Previous Image (Left Arrow)"
                >
                   <ChevronLeft className="w-8 h-8" />
                </button>
                <button 
                  onClick={handleNextImage}
                  className="absolute right-4 sm:right-8 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-all z-50"
                  title="Next Image (Right Arrow)"
                >
                   <ChevronRight className="w-8 h-8" />
                </button>
             </>
          )}

          {/* Image Counter */}
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 bg-black/50 text-white px-4 py-2 rounded-full text-sm font-medium border border-white/10 backdrop-blur-md z-50">
             Image {fullscreenIndex + 1} of {images.length}
          </div>
          
          {/* Active Image */}
          <img 
            src={images[fullscreenIndex]} 
            alt="Fullscreen View" 
            className="max-w-full max-h-[90vh] object-contain rounded shadow-2xl animate-in zoom-in-95 duration-300 select-none"
            onClick={(e) => e.stopPropagation()} // Prevent clicking image from closing
          />
        </div>
      )}
    </div>
  );
}
