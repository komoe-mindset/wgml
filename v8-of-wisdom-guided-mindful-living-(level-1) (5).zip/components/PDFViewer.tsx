
import React, { useEffect, useRef, useState } from 'react';
import * as pdfjsLib from 'pdfjs-dist';
import { ChevronLeft, ChevronRight, ZoomIn, ZoomOut, Maximize, Loader2, Scaling } from 'lucide-react';

// Fix for "Cannot set properties of undefined (setting 'workerSrc')"
const pdfjs = (pdfjsLib as any).default || pdfjsLib;

// Configure worker
if (pdfjs.GlobalWorkerOptions) {
  pdfjs.GlobalWorkerOptions.workerSrc = `https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/build/pdf.worker.min.js`;
}

interface Props {
  pdfUrl: string;
  isPresentationMode?: boolean;
}

export const PDFViewer: React.FC<Props> = ({ pdfUrl, isPresentationMode = false }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [pdfDoc, setPdfDoc] = useState<any>(null);
  const [pageNum, setPageNum] = useState(1);
  const [numPages, setNumPages] = useState(0);
  const [scale, setScale] = useState(1.5);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const dragStartRef = useRef({ x: 0, y: 0 });
  
  // Ref to keep track of render task for cancellation
  const renderTaskRef = useRef<any>(null);

  useEffect(() => {
    let isMounted = true;
    
    const loadPdf = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const loadingTask = pdfjs.getDocument(pdfUrl);
        const pdf = await loadingTask.promise;
        if (isMounted) {
          setPdfDoc(pdf);
          setNumPages(pdf.numPages);
          setIsLoading(false);
        }
      } catch (err) {
        console.error('Error loading PDF:', err);
        if (isMounted) {
          setError('Failed to load PDF.');
          setIsLoading(false);
        }
      }
    };

    loadPdf();

    return () => {
      isMounted = false;
    };
  }, [pdfUrl]);

  useEffect(() => {
    if (!pdfDoc) return;

    const renderPage = async () => {
      try {
        // Cancel any pending render task
        if (renderTaskRef.current) {
            renderTaskRef.current.cancel();
        }

        const page = await pdfDoc.getPage(pageNum);
        const canvas = canvasRef.current;
        const context = canvas?.getContext('2d');
        
        if (!canvas || !context || !containerRef.current) return;

        // Calculate scale to fit container width if presentation mode
        let finalScale = scale;
        if (isPresentationMode) {
            const viewport = page.getViewport({ scale: 1 });
            const containerWidth = containerRef.current.clientWidth;
            const containerHeight = containerRef.current.clientHeight;
            
            const widthScale = (containerWidth - 40) / viewport.width;
            const heightScale = (containerHeight - 80) / viewport.height;
            finalScale = Math.min(widthScale, heightScale);
        }

        // High DPI support
        const pixelRatio = window.devicePixelRatio || 1;
        const viewport = page.getViewport({ scale: finalScale * pixelRatio });

        canvas.height = viewport.height;
        canvas.width = viewport.width;
        
        // CSS Size needs to match the viewport size (divided by pixel ratio)
        canvas.style.width = `${viewport.width / pixelRatio}px`;
        canvas.style.height = `${viewport.height / pixelRatio}px`;

        const renderContext = {
          canvasContext: context,
          viewport: viewport,
          transform: [pixelRatio, 0, 0, pixelRatio, 0, 0] // Identity matrix scaled by pixel ratio
        };
        
        // Store render task
        const renderTask = page.render(renderContext);
        renderTaskRef.current = renderTask;

        await renderTask.promise;
        renderTaskRef.current = null; // Clear task when done
        
      } catch (err: any) {
        if (err.name === 'RenderingCancelledException') {
            // This is expected when we cancel quickly
            console.log('Rendering cancelled');
        } else {
            console.error('Error rendering page:', err);
        }
      }
    };

    renderPage();
    
    // Cleanup on unmount or dependency change
    return () => {
        if (renderTaskRef.current) {
            renderTaskRef.current.cancel();
        }
    };
  }, [pdfDoc, pageNum, scale, isPresentationMode]);

  const changePage = (offset: number) => {
    setPageNum(prev => Math.min(Math.max(1, prev + offset), numPages));
  };

  // Zoom handlers
  const handleWheel = (e: React.WheelEvent) => {
      if (e.ctrlKey || e.metaKey) {
          e.preventDefault();
          if (e.deltaY < 0) {
              setScale(s => Math.min(3, s + 0.1));
          } else {
              setScale(s => Math.max(0.5, s - 0.1));
          }
      }
  };

  // Pan handlers (Simple implementation for overflow scroll)
  const handleMouseDown = (e: React.MouseEvent) => {
      if (scale > 1) {
          setIsDragging(true);
          dragStartRef.current = { x: e.clientX, y: e.clientY };
      }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
      if (isDragging && containerRef.current) {
          const dx = e.clientX - dragStartRef.current.x;
          const dy = e.clientY - dragStartRef.current.y;
          containerRef.current.scrollLeft -= dx;
          containerRef.current.scrollTop -= dy;
          dragStartRef.current = { x: e.clientX, y: e.clientY };
      }
  };

  const handleMouseUp = () => {
      setIsDragging(false);
  };

  if (error) {
    return (
        <div className="flex flex-col items-center justify-center h-full bg-slate-50 text-slate-500 p-8 rounded-lg border border-dashed border-slate-200">
            <p>{error}</p>
            <a href={pdfUrl} download className="mt-4 text-indigo-600 underline text-sm">Download PDF instead</a>
        </div>
    );
  }

  return (
    <div 
        ref={containerRef} 
        className={`flex flex-col items-center h-full w-full ${isPresentationMode ? 'bg-slate-900' : 'bg-slate-50 rounded-lg border border-slate-200'} overflow-hidden relative`}
        onWheel={handleWheel}
    >
      {/* Controls - Different for Normal vs Presentation Mode */}
      {isPresentationMode ? (
         /* Presentation Mode Controls - Floating Pill at Bottom */
         <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex items-center justify-between p-3 bg-slate-800/90 text-white w-auto rounded-full gap-6 shadow-2xl backdrop-blur-sm z-50 px-6 border border-white/10 transition-all hover:bg-slate-800">
            <div className="flex items-center gap-2">
                <button onClick={() => changePage(-1)} disabled={pageNum <= 1} className="p-1.5 rounded hover:bg-white/20 disabled:opacity-30"><ChevronLeft className="w-5 h-5" /></button>
                <span className="text-sm font-medium tabular-nums text-slate-200">{pageNum} / {numPages}</span>
                <button onClick={() => changePage(1)} disabled={pageNum >= numPages} className="p-1.5 rounded hover:bg-white/20 disabled:opacity-30"><ChevronRight className="w-5 h-5" /></button>
            </div>
            <div className="w-px h-4 bg-white/20 mx-1"></div>
            <div className="flex items-center gap-2">
                <button onClick={() => setScale(s => Math.max(0.5, s - 0.2))} className="p-1.5 rounded hover:bg-white/20"><ZoomOut className="w-4 h-4" /></button>
                <button onClick={() => setScale(s => Math.min(3, s + 0.2))} className="p-1.5 rounded hover:bg-white/20"><ZoomIn className="w-4 h-4" /></button>
            </div>
         </div>
      ) : (
         /* Normal Mode Controls - Static Bar at Top */
         <div className="w-full flex items-center justify-between p-2 bg-slate-100 border-b border-slate-200 text-slate-600 shrink-0">
            <div className="flex items-center gap-2">
                <button onClick={() => changePage(-1)} disabled={pageNum <= 1} className="p-1 rounded hover:bg-white disabled:opacity-40"><ChevronLeft className="w-4 h-4" /></button>
                <span className="text-xs font-medium tabular-nums bg-white px-2 py-0.5 rounded border border-slate-200 shadow-sm">{pageNum} / {numPages}</span>
                <button onClick={() => changePage(1)} disabled={pageNum >= numPages} className="p-1 rounded hover:bg-white disabled:opacity-40"><ChevronRight className="w-4 h-4" /></button>
            </div>
            {/* Simple page indicator or minimal actions could go here if needed */}
            <div className="text-xs text-slate-400 font-medium">PDF Viewer</div>
         </div>
      )}

      {/* Canvas / Loader */}
      <div 
        className={`flex-1 w-full overflow-auto flex items-start justify-center p-4 relative ${isPresentationMode ? 'bg-transparent' : 'bg-slate-50'} ${isDragging ? 'cursor-grabbing' : 'cursor-default'}`}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        {isLoading && (
            <div className="absolute inset-0 flex items-center justify-center z-10">
                <Loader2 className="w-8 h-8 animate-spin text-indigo-500" />
            </div>
        )}
        <canvas ref={canvasRef} className="shadow-md bg-white" />
      </div>
    </div>
  );
};
