import React, { useState } from 'react';
import { X, GraduationCap, UserCog, BookOpen, Download, Upload, Bot, PlayCircle, FileDown, Edit3, Save, ExternalLink, HelpCircle } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  language: 'my' | 'en';
  defaultRole?: 'teacher' | 'student';
}

export const UserGuide: React.FC<Props> = ({ isOpen, onClose, language, defaultRole = 'student' }) => {
  const [activeTab, setActiveTab] = useState<'student' | 'teacher'>(defaultRole);

  if (!isOpen) return null;

  const content = {
    teacher: {
      title: language === 'my' ? "ဆရာများအတွက် လမ်းညွှန်" : "Teacher Guide",
      steps: [
        {
          title: language === 'my' ? "၁။ ဝင်ရောက်ခြင်း (Login)" : "1. Login Access",
          desc: language === 'my' ? "Login Access တွင် Teacher ခလုတ်ကိုနှိပ်ပါ။ PIN နံပါတ် (1234) ကိုရိုက်ထည့်ပါ။" : "Click 'Teacher' button. Enter PIN code (Default: 1234).",
          icon: <UserCog className="w-5 h-5 text-indigo-600" />
        },
        {
          title: language === 'my' ? "၂။ သင်ခန်းစာ ပြင်ဆင်ခြင်း" : "2. Editing Content",
          desc: language === 'my' ? "'Edit Notes' ခလုတ်ဖြင့် စာများကို ပြင်ဆင်နိုင်သည်။ ပုံများထည့်ရန် 'Upload Images' ကိုသုံးပါ။" : "Use 'Edit Notes' to change text. Use 'Upload Images' in Gallery/Visual Aid tabs.",
          icon: <Edit3 className="w-5 h-5 text-blue-600" />
        },
        {
            title: language === 'my' ? "၃။ Quiz ဖန်တီးခြင်း (AI)" : "3. Creating Quizzes with AI",
            desc: language === 'my' ? "Quiz Tab တွင် 'Copy Prompt' ကိုနှိပ်ပါ။ Gemini တွင် Paste (Ctrl+V) လုပ်ပြီး ရလာသော JSON ကို ပြန်လည်ထည့်သွင်းပါ။" : "In Quiz Tab, click 'Copy Prompt'. Paste into Gemini. Copy the JSON result back into the app.",
            icon: <Bot className="w-5 h-5 text-purple-600" />
        },
        {
            title: language === 'my' ? "၄။ သိမ်းဆည်းခြင်း (Export)" : "4. Export Package",
            desc: language === 'my' ? "သင်ခန်းစာများကို သိမ်းဆည်းရန် ညာဘက်အပေါ်ရှိ 'Export' ခလုတ်ကို နှိပ်ပါ။ (.zip) ဖိုင်ရရှိပါမည်။" : "Click 'Export' in the top right to save all changes as a .zip file. Share this file with students.",
            icon: <Download className="w-5 h-5 text-green-600" />
        }
      ]
    },
    student: {
      title: language === 'my' ? "ကျောင်းသားများအတွက် လမ်းညွှန်" : "Student Guide",
      steps: [
        {
          title: language === 'my' ? "၁။ သင်ခန်းစာ ယူဆောင်ခြင်း (Import)" : "1. Import Lesson Package",
          desc: language === 'my' ? "ဆရာပေးပို့သော (.zip) ဖိုင်ကို 'Import' ခလုတ်နှိပ်၍ ထည့်သွင်းပါ။" : "Click 'Import' on the login screen and select the .zip file provided by your teacher.",
          icon: <Upload className="w-5 h-5 text-orange-600" />
        },
        {
          title: language === 'my' ? "၂။ လေ့လာခြင်း" : "2. Studying",
          desc: language === 'my' ? "သင်ခန်းစာစာသား (Notes)၊ ပုံဥပမာ (Visual Aid) နှင့် ပုံများ (Gallery) ကို လေ့လာပါ။" : "Navigate through Notes, Visual Aids, and Gallery tabs to study the chapter.",
          icon: <BookOpen className="w-5 h-5 text-blue-600" />
        },
        {
            title: language === 'my' ? "၃။ မေးမြန်းခြင်း (AI Tutor)" : "3. Ask AI Tutor",
            desc: language === 'my' ? "နားမလည်သည်များရှိပါက ညာဘက်အောက်ထောင့်ရှိ 'AI Tutor' ခလုတ်ဖြင့် မေးမြန်းနိုင်ပါသည်။" : "Use the floating 'AI Tutor' button to ask questions about the lesson.",
            icon: <Bot className="w-5 h-5 text-purple-600" />
        },
        {
            title: language === 'my' ? "၄။ ဖြေဆိုခြင်းနှင့် လက်မှတ်" : "4. Quiz & Certificate",
            desc: language === 'my' ? "Quiz ဖြေဆို၍ အမှတ်ပြည့်ရပါက ဂုဏ်ပြုလက်မှတ် (Certificate) ကို Download ရယူနိုင်ပါသည်။" : "Take the Quiz. If you score 100%, you can download a Certificate of Achievement.",
            icon: <FileDown className="w-5 h-5 text-yellow-600" />
        }
      ]
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-slate-100 p-4 border-b border-slate-200 flex justify-between items-center shrink-0">
          <div className="flex items-center gap-2">
            <HelpCircle className="w-6 h-6 text-indigo-600" />
            <h2 className={`text-lg font-bold text-slate-800 ${language === 'my' ? 'font-burmese' : ''}`}>
               {language === 'my' ? 'အသုံးပြုပုံ လမ်းညွှန်' : 'User Manual / Guide'}
            </h2>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-200 rounded-full transition-colors">
            <X className="w-5 h-5 text-slate-500" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-200 bg-white shrink-0">
          <button 
            onClick={() => setActiveTab('student')}
            className={`flex-1 py-4 text-center font-bold text-sm flex items-center justify-center gap-2 border-b-2 transition-colors ${activeTab === 'student' ? 'border-green-500 text-green-700 bg-green-50' : 'border-transparent text-slate-500 hover:bg-slate-50'}`}
          >
            <GraduationCap className="w-5 h-5" />
            <span className={language === 'my' ? 'font-burmese' : ''}>{language === 'my' ? 'ကျောင်းသား' : 'Student Mode'}</span>
          </button>
          <button 
            onClick={() => setActiveTab('teacher')}
            className={`flex-1 py-4 text-center font-bold text-sm flex items-center justify-center gap-2 border-b-2 transition-colors ${activeTab === 'teacher' ? 'border-indigo-500 text-indigo-700 bg-indigo-50' : 'border-transparent text-slate-500 hover:bg-slate-50'}`}
          >
            <UserCog className="w-5 h-5" />
            <span className={language === 'my' ? 'font-burmese' : ''}>{language === 'my' ? 'ဆရာ' : 'Teacher Mode'}</span>
          </button>
        </div>

        {/* Content */}
        <div className="p-6 md:p-8 overflow-y-auto custom-scrollbar flex-1">
           <h3 className={`text-xl font-bold mb-6 text-slate-800 ${language === 'my' ? 'font-burmese' : ''}`}>
             {content[activeTab].title}
           </h3>

           <div className="space-y-6">
             {content[activeTab].steps.map((step, idx) => (
               <div key={idx} className="flex gap-4 p-4 bg-slate-50 rounded-xl border border-slate-200 hover:border-indigo-200 transition-colors">
                 <div className="shrink-0 w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-sm border border-slate-100 mt-1">
                   {step.icon}
                 </div>
                 <div>
                   <h4 className={`font-bold text-slate-800 text-base mb-1 ${language === 'my' ? 'font-burmese leading-relaxed' : ''}`}>
                     {step.title}
                   </h4>
                   <p className={`text-sm text-slate-600 ${language === 'my' ? 'font-burmese leading-loose' : 'leading-relaxed'}`}>
                     {step.desc}
                   </p>
                 </div>
               </div>
             ))}
           </div>
           
           {/* Pro Tip */}
           <div className="mt-8 p-4 bg-yellow-50 border border-yellow-200 rounded-xl flex gap-3 items-start">
              <span className="text-xl">💡</span>
              <p className={`text-sm text-yellow-800 ${language === 'my' ? 'font-burmese leading-loose' : ''}`}>
                <strong>Tip:</strong> {activeTab === 'teacher' 
                  ? (language === 'my' ? "ပို့ချချက်များကို တင်ပြီးတိုင်း Export လုပ်၍ သိမ်းဆည်းရန် မမေ့ပါနှင့်။" : "Always remember to Export your package after making changes to save your work.")
                  : (language === 'my' ? "Quiz မဖြေဆိုခင် သင်ခန်းစာများကို သေချာစွာ လေ့လာပါ။" : "Make sure to review the Visual Aids before starting the Quiz.")}
              </p>
           </div>
        </div>
        
        {/* Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 shrink-0 flex justify-end">
            <button 
                onClick={onClose}
                className="px-6 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg transition-colors"
            >
                {language === 'my' ? 'နားလည်ပါပြီ' : 'Got it'}
            </button>
        </div>
      </div>
    </div>
  );
};