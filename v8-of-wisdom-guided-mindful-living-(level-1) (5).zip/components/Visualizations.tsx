
import React from 'react';
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip } from 'recharts';
import { ArrowRight, Eye, Brain, ShieldCheck, Hand, Scale, Zap, CloudRain, Sun, Clock, Home, Ghost, Repeat } from 'lucide-react';

// --- Chapter 1: Roots ---
export const RootsTree = () => (
  <div className="flex flex-col items-center justify-center p-6 bg-green-50 rounded-xl border-2 border-green-100 h-full">
    <h3 className="text-lg font-bold mb-6 text-green-800 font-burmese leading-loose">ကုသိုလ် နှင့် အကုသိုလ် အရင်းအမြစ်များ</h3>
    <div className="flex flex-wrap justify-center gap-8">
      {/* Akusala */}
      <div className="flex flex-col gap-4 p-4 bg-red-50 rounded-xl border border-red-100">
        <h4 className="font-bold text-red-700 text-center mb-2">Akusala (အကုသိုလ်)</h4>
        <div className="flex gap-4">
          <div className="flex flex-col items-center">
            <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center border-2 border-red-200 shadow-sm">
              <span className="text-xl">😡</span>
            </div>
            <span className="text-xs font-bold text-red-600 mt-1">Dosa</span>
          </div>
          <div className="flex flex-col items-center">
            <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center border-2 border-red-200 shadow-sm">
              <span className="text-xl">🤑</span>
            </div>
            <span className="text-xs font-bold text-blue-600 mt-1">Lobha</span>
          </div>
          <div className="flex flex-col items-center">
            <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center border-2 border-red-200 shadow-sm">
              <span className="text-xl">😵‍💫</span>
            </div>
            <span className="text-xs font-bold text-gray-600 mt-1">Moha</span>
          </div>
        </div>
      </div>

      {/* Kusala */}
      <div className="flex flex-col gap-4 p-4 bg-green-100 rounded-xl border border-green-200">
        <h4 className="font-bold text-green-700 text-center mb-2">Kusala (ကုသိုလ်)</h4>
        <div className="flex gap-4">
          <div className="flex flex-col items-center">
            <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center border-2 border-green-300 shadow-sm">
              <HeartIcon className="w-6 h-6 text-red-500" />
            </div>
            <span className="text-xs font-bold text-green-700 mt-1">A-Dosa</span>
          </div>
          <div className="flex flex-col items-center">
            <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center border-2 border-green-300 shadow-sm">
              <Hand className="w-6 h-6 text-blue-500" />
            </div>
            <span className="text-xs font-bold text-green-700 mt-1">A-Lobha</span>
          </div>
          <div className="flex flex-col items-center">
            <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center border-2 border-green-300 shadow-sm">
              <LightbulbIcon className="w-6 h-6 text-yellow-500" />
            </div>
            <span className="text-xs font-bold text-green-700 mt-1">A-Moha</span>
          </div>
        </div>
      </div>
    </div>
  </div>
);

// --- Chapter 2: Kamma vs Nana ---
export const KammaVsNana = () => (
  <div className="flex flex-col md:flex-row gap-6 h-full p-4">
    <div className="flex-1 bg-orange-50 rounded-xl border border-orange-200 p-6 flex flex-col items-center text-center relative overflow-hidden">
      <div className="absolute top-0 right-0 p-4 opacity-10"><Repeat className="w-24 h-24" /></div>
      <div className="z-10">
        <h3 className="font-bold text-orange-800 text-lg mb-2 font-burmese leading-loose">ကံကုသိုလ် (Kamma)</h3>
        <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-sm text-2xl">🌱</div>
        <p className="text-sm font-burmese text-orange-900 mb-2 leading-relaxed">မျိုးစေ့နှင့်တူသည်</p>
        <div className="mt-4 p-3 bg-white/80 rounded-lg text-xs font-bold text-orange-700">
          ရလဒ် = သံသရာလည်ခြင်း
        </div>
      </div>
    </div>

    <div className="flex items-center justify-center text-slate-400 font-bold">VS</div>

    <div className="flex-1 bg-indigo-50 rounded-xl border border-indigo-200 p-6 flex flex-col items-center text-center relative overflow-hidden">
      <div className="absolute top-0 right-0 p-4 opacity-10"><Zap className="w-24 h-24" /></div>
      <div className="z-10">
        <h3 className="font-bold text-indigo-800 text-lg mb-2 font-burmese leading-loose">ဉာဏ်ကုသိုလ် (Ñāṇa)</h3>
        <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-sm text-2xl">🌳</div>
        <p className="text-sm font-burmese text-indigo-900 mb-2 leading-relaxed">ညောင်ပင်ကြီးနှင့်တူသည်</p>
        <div className="mt-4 p-3 bg-white/80 rounded-lg text-xs font-bold text-indigo-700">
          ရလဒ် = နိဗ္ဗာန် (လွတ်မြောက်ခြင်း)
        </div>
      </div>
    </div>
  </div>
);

// --- Chapter 3: Sila Samadhi Panna ---
export const SilaSamadhiPanna = () => {
  const data = [
    { name: 'Sila (Morality)', value: 1, color: '#3b82f6' },
    { name: 'Samadhi (Concentration)', value: 1, color: '#8b5cf6' },
    { name: 'Panna (Wisdom)', value: 1, color: '#f59e0b' },
  ];

  return (
    <div className="h-full w-full bg-white rounded-xl border border-slate-100 shadow-sm flex flex-col items-center justify-center p-6">
      <h3 className="text-lg font-bold mb-2 font-burmese leading-loose text-slate-700">သိက္ခာ (၃) ပါး</h3>
      <ResponsiveContainer width="100%" height={250}>
        <PieChart>
          <Pie
            data={data}
            innerRadius={60}
            outerRadius={80}
            paddingAngle={5}
            dataKey="value"
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Pie>
          <Tooltip />
        </PieChart>
      </ResponsiveContainer>
      <div className="flex flex-wrap justify-center gap-4 text-xs font-burmese mt-4">
        <div className="flex items-center gap-1">
          <div className="w-3 h-3 rounded-full bg-blue-500"></div>
          <span>သီလ (အကျင့်)</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-3 h-3 rounded-full bg-purple-500"></div>
          <span>သမာဓိ (တည်ငြိမ်မှု)</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-3 h-3 rounded-full bg-orange-500"></div>
          <span>ပညာ (အသိဉာဏ်)</span>
        </div>
      </div>
    </div>
  );
};

// --- Chapter 4: Front Mind vs Back Mind ---
export const MindProcess = () => (
  <div className="flex flex-col md:flex-row items-center justify-between p-6 bg-slate-50 rounded-xl border border-slate-200 gap-6 h-full">
    <div className="bg-white p-6 rounded-xl shadow-md text-center flex-1 border-l-4 border-blue-500 h-full flex flex-col items-center justify-center">
      <Eye className="w-10 h-10 mx-auto text-blue-500 mb-3" />
      <h4 className="font-bold text-slate-800 font-burmese leading-loose">ရှေ့စိတ် (မြင်စိတ်)</h4>
      <p className="text-sm text-slate-500 font-burmese leading-relaxed">အရောင်/သဏ္ဍာန်ကိုသာ မြင်သည်</p>
      <div className="mt-3 text-xs bg-blue-100 text-blue-800 py-1 px-3 rounded-full inline-block font-bold">Paramattha (ပရမတ်)</div>
    </div>
    
    <div className="flex flex-col items-center text-slate-400">
      <span className="text-xs font-bold mb-1">Process</span>
      <ArrowRight className="w-8 h-8 animate-pulse" />
    </div>
    
    <div className="bg-white p-6 rounded-xl shadow-md text-center flex-1 border-l-4 border-purple-500 h-full flex flex-col items-center justify-center">
      <Brain className="w-10 h-10 mx-auto text-purple-500 mb-3" />
      <h4 className="font-bold text-slate-800 font-burmese leading-loose">နောက်စိတ် (သိစိတ်)</h4>
      <p className="text-sm text-slate-500 font-burmese leading-relaxed">'ရေ'၊ 'လူ' ဟု အမည်တပ်သိသည်</p>
      <div className="mt-3 text-xs bg-purple-100 text-purple-800 py-1 px-3 rounded-full inline-block font-bold">Pannatti (ပညတ်)</div>
    </div>
  </div>
);

// --- Chapter 5: Vedana (Feeling) ---
export const VedanaCycle = () => (
  <div className="flex flex-col items-center justify-center h-full p-6 bg-gradient-to-b from-blue-50 to-white rounded-xl border border-blue-100">
    <h3 className="font-bold text-lg mb-8 font-burmese leading-loose text-slate-700">ဝေဒနာ (၃) မျိုး</h3>
    <div className="flex items-end gap-4 md:gap-8">
      {/* Dukkha */}
      <div className="flex flex-col items-center gap-2">
        <div className="w-20 h-24 bg-red-100 rounded-t-xl flex items-end justify-center pb-2 relative group hover:h-32 transition-all duration-500">
          <CloudRain className="w-8 h-8 text-red-500" />
        </div>
        <span className="font-bold text-red-600 font-burmese">ဒုက္ခ</span>
        <span className="text-xs text-slate-400">ဆင်းရဲ</span>
      </div>

      {/* Upekkha */}
      <div className="flex flex-col items-center gap-2">
        <div className="w-20 h-16 bg-gray-100 rounded-t-xl flex items-end justify-center pb-2 relative group hover:h-32 transition-all duration-500">
          <Scale className="w-8 h-8 text-gray-500" />
        </div>
        <span className="font-bold text-gray-600 font-burmese">ဥပေက္ခာ</span>
        <span className="text-xs text-slate-400">အလယ်အလတ်</span>
      </div>

      {/* Sukha */}
      <div className="flex flex-col items-center gap-2">
        <div className="w-20 h-32 bg-green-100 rounded-t-xl flex items-end justify-center pb-2 relative group hover:h-40 transition-all duration-500">
          <Sun className="w-8 h-8 text-orange-500" />
        </div>
        <span className="font-bold text-green-600 font-burmese">သုခ</span>
        <span className="text-xs text-slate-400">ချမ်းသာ</span>
      </div>
    </div>
    <div className="w-full h-1 bg-slate-300 rounded-full mt-1"></div>
    <p className="mt-6 text-sm text-center font-burmese text-slate-500 leading-relaxed max-w-md">
      အာရုံနှင့် တိုက်ဆိုင်မှု (ဖဿ) ကြောင့် ခံစားမှု (ဝေဒနာ) ဖြစ်ပေါ်လာသည်။ "ငါ" ခံစားသည် မဟုတ်ပါ။
    </p>
  </div>
);

// --- Chapter 6: Sanna (Perception) ---
export const SannaPerception = () => (
  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 h-full p-4">
    <div className="bg-slate-800 rounded-xl p-6 text-white flex flex-col items-center justify-center relative overflow-hidden">
      <div className="absolute inset-0 bg-black/50 z-0"></div>
      <div className="z-10 flex flex-col items-center">
        <Ghost className="w-16 h-16 text-yellow-200 mb-4 animate-bounce" />
        <h4 className="font-bold font-burmese text-lg leading-loose">မှားယွင်းသော အမြင်</h4>
        <p className="text-sm opacity-80 font-burmese text-center">သညာ၏ လှည့်စားမှု (တံလျှပ်ကို ရေထင်ခြင်း)</p>
      </div>
    </div>
    <div className="bg-white rounded-xl border-2 border-indigo-100 p-6 flex flex-col items-center justify-center">
      <div className="relative">
        <Brain className="w-16 h-16 text-indigo-600 mb-4" />
        <div className="absolute -top-2 -right-2 bg-green-500 rounded-full p-1">
          <ShieldCheck className="w-4 h-4 text-white" />
        </div>
      </div>
      <h4 className="font-bold text-indigo-900 font-burmese text-lg leading-loose">မှန်ကန်သော အသိ</h4>
      <p className="text-sm text-slate-500 font-burmese text-center">ပညာဖြင့် အမှန်တရားကို သိမြင်ခြင်း</p>
    </div>
  </div>
);

// --- Chapter 7: Present Moment ---
export const PresentMoment = () => (
  <div className="flex flex-col items-center justify-center h-full p-6 bg-slate-50 rounded-xl">
    <div className="flex items-center gap-4 w-full max-w-lg mb-8">
      <div className="flex-1 text-center opacity-40 blur-[1px]">
        <h4 className="font-bold font-burmese">အတိတ်</h4>
        <p className="text-xs">Past</p>
      </div>
      <div className="flex-1 text-center transform scale-125 font-bold text-indigo-700 bg-white p-4 rounded-xl shadow-lg border border-indigo-100 z-10">
        <Clock className="w-8 h-8 mx-auto mb-2 text-indigo-500" />
        <h4 className="font-burmese leading-loose">ပစ္စုပ္ပန်</h4>
        <p className="text-xs uppercase tracking-wide">Now</p>
      </div>
      <div className="flex-1 text-center opacity-40 blur-[1px]">
        <h4 className="font-bold font-burmese">အနာဂတ်</h4>
        <p className="text-xs">Future</p>
      </div>
    </div>
    <div className="bg-indigo-100 px-6 py-3 rounded-full text-indigo-800 font-burmese text-center leading-relaxed">
      "ပစ္စုပ္ပန်တည့်တည့်ကို ရှုမှတ်ခြင်းသည် ဉာဏ်ဖြစ်သည်"
    </div>
  </div>
);

// --- Chapter 8: Host vs Guest ---
export const HostGuest = () => (
  <div className="relative h-full p-6 bg-white rounded-xl border border-slate-200 overflow-hidden flex flex-col items-center justify-center">
    <div className="flex justify-between w-full max-w-md items-end">
      
      {/* Host */}
      <div className="flex flex-col items-center z-10">
        <div className="w-24 h-24 bg-blue-50 rounded-t-full border-2 border-blue-200 flex items-center justify-center relative">
          <Home className="w-10 h-10 text-blue-600" />
          <div className="absolute -bottom-3 bg-blue-600 text-white text-[10px] px-2 py-0.5 rounded-full uppercase">Host</div>
        </div>
        <div className="bg-white p-2 rounded shadow-sm border border-slate-100 mt-2 text-center">
          <p className="font-bold font-burmese text-sm text-slate-700">ရုပ်နာမ်</p>
          <p className="text-[10px] text-slate-400">အိမ်ရှင်</p>
        </div>
      </div>

      {/* Guests */}
      <div className="flex flex-col items-center z-10">
        <div className="flex -space-x-4 mb-2">
           <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center border-2 border-white shadow-sm" title="Lobha">🤑</div>
           <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center border-2 border-white shadow-sm" title="Dosa">😡</div>
           <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center border-2 border-white shadow-sm" title="Moha">😵‍💫</div>
        </div>
        <div className="bg-white p-2 rounded shadow-sm border border-slate-100 mt-2 text-center">
          <p className="font-bold font-burmese text-sm text-red-600">ကိလေသာ</p>
          <p className="text-[10px] text-slate-400">ဧည့်သည်များ</p>
        </div>
      </div>

    </div>
    <div className="mt-8 text-center bg-slate-50 p-4 rounded-lg w-full max-w-md">
      <p className="font-burmese text-slate-600 leading-relaxed text-sm">
        "စိတ်ဆိုးတာ ငါမဟုတ်၊ ဧည့်သည် (ကိလေသာ) ဝင်လာခြင်းသာ ဖြစ်သည်။"
      </p>
    </div>
  </div>
);

// --- Chapter 9: Sati vs Upadana ---
export const SatiVsUpadana = () => (
  <div className="relative p-8 bg-gradient-to-r from-orange-50 to-red-50 rounded-xl border border-orange-200 overflow-hidden h-full flex flex-col justify-center">
    <div className="flex flex-col md:flex-row justify-between items-center z-10 relative gap-8">
      <div className="flex flex-col items-center p-6 bg-white/90 rounded-xl shadow-sm border-b-4 border-green-500 w-full md:w-1/3">
        <ShieldCheck className="w-12 h-12 text-green-600 mb-2" />
        <h4 className="font-bold font-burmese text-lg leading-loose">သတိ (Sati)</h4>
        <p className="text-xs text-center text-slate-500 font-burmese">စိတ်တံခါးစောင့် (အကာအကွယ်)</p>
      </div>
      
      <div className="flex flex-col items-center">
        <span className="text-3xl font-bold text-slate-400/50">VS</span>
      </div>

      <div className="flex flex-col items-center p-6 bg-white/90 rounded-xl shadow-sm border-b-4 border-red-500 w-full md:w-1/3">
        <Hand className="w-12 h-12 text-red-600 mb-2" />
        <h4 className="font-bold font-burmese text-lg leading-loose">ဥပါဒါန် (Upadana)</h4>
        <p className="text-xs text-center text-slate-500 font-burmese">စွဲလမ်းကပ်ငြိခြင်း (ကော်)</p>
      </div>
    </div>
    <p className="text-center mt-8 text-sm md:text-base italic text-slate-700 font-medium font-burmese leading-relaxed bg-white/50 p-2 rounded-lg backdrop-blur-sm">
      "သတိရှိလျှင် ဥပါဒါန်မကပ်နိုင်၊ ဥပါဒါန်ကပ်လျှင် သတိမရှိ။"
    </p>
  </div>
);

// Internal Icons helper
const HeartIcon = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
    <path d="M11.645 20.91l-.007-.003-.022-.012a15.247 15.247 0 01-.383-.218 25.18 25.18 0 01-4.244-3.17C4.688 15.36 2.25 12.174 2.25 8.25 2.25 5.322 4.714 3 7.688 3A5.5 5.5 0 0112 5.052 5.5 5.5 0 0116.313 3c2.973 0 5.437 2.322 5.437 5.25 0 3.925-2.438 7.111-4.739 9.256a25.175 25.175 0 01-4.244 3.17 15.247 15.247 0 01-.383.219l-.022.012-.007.004-.003.001a.752.752 0 01-.704 0l-.003-.001z" />
  </svg>
);

const LightbulbIcon = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
    <path d="M12 2.25a.75.75 0 01.75.75v2.25a.75.75 0 01-1.5 0V3a.75.75 0 01.75-.75zM7.5 12a4.5 4.5 0 119 0 4.5 4.5 0 01-9 0zM18.894 6.166a.75.75 0 00-1.06-1.06l-1.591 1.59a.75.75 0 101.06 1.061l1.591-1.59zM21.75 12a.75.75 0 01-.75.75h-2.25a.75.75 0 010-1.5H21a.75.75 0 01.75.75zM17.834 18.894a.75.75 0 001.06-1.06l-1.59-1.591a.75.75 0 10-1.061 1.06l1.59 1.591zM12 18a.75.75 0 01.75.75V21a.75.75 0 01-1.5 0v-2.25A.75.75 0 0112 18zM7.758 17.303a.75.75 0 00-1.061-1.06l-1.591 1.59a.75.75 0 001.06 1.061l1.591-1.59zM6 12a.75.75 0 01-.75.75H3a.75.75 0 010-1.5h2.25A.75.75 0 016 12zM6.697 7.757a.75.75 0 001.06-1.06l-1.59-1.591a.75.75 0 00-1.061 1.06l1.59 1.591z" />
  </svg>
);
