import React, { useState, useEffect } from 'react';
import { WifiOff, CheckCircle2 } from 'lucide-react';

export const OfflineBanner: React.FC = () => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [showBackOnline, setShowBackOnline] = useState(false);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setShowBackOnline(true);
      setTimeout(() => setShowBackOnline(false), 3000);
    };
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  if (!isOnline) {
    return (
      <div className="bg-slate-800 text-white px-4 py-1.5 text-xs font-bold flex items-center justify-center gap-2 animate-in slide-in-from-top-full">
        <WifiOff className="w-3.5 h-3.5 text-red-400" />
        <span>Offline Mode Active • You can still study saved content.</span>
      </div>
    );
  }

  if (showBackOnline) {
    return (
      <div className="bg-green-600 text-white px-4 py-1.5 text-xs font-bold flex items-center justify-center gap-2 animate-in slide-in-from-top-full fade-out duration-1000">
        <CheckCircle2 className="w-3.5 h-3.5" />
        <span>Back Online</span>
      </div>
    );
  }

  return null;
};